

function in_beh(){
    var use_pro = document.getElementsByName('use_pro');
    var reg_lan = document.getElementsByName('reg_lan');
    var create_ticket = document.getElementsByName('create_ticket');
    var eng_rude = document.getElementsByName('eng_rude');
    var release_call = document.getElementsByName('release_call');
    
 
    var op=0;
    

    for(i = 0; i < create_ticket.length; i++){
        if(create_ticket[i].checked){
        
            if(create_ticket[i].value==101){
                op+=10;
               
            }
          
            
            else{
                op+=parseInt(create_ticket[i].value);
                
                break;
                
            }
        
        }
    }


    
    for(i = 0; i < use_pro.length; i++){
        if(use_pro[i].checked){

            if(use_pro[i].value==101){
                op+=10;
               
            } 
           
            else{
                op+=parseInt(use_pro[i].value);
               
                break;
               
            }
           
        } 
    }
    for(i = 0; i < release_call.length; i++){
        if(release_call[i].checked){
            if(release_call[i].value==101){
                op+=10;
              
            } 
           
            else{
                op+=parseInt(release_call[i].value);
              
                break;
                
            }
           
        } 
    }

   
    for(i = 0; i < eng_rude.length; i++){
        if(eng_rude[i].checked){
            if(eng_rude[i].value==101){
                op+=10;
               
            } 
           
            else{
                op+=parseInt(eng_rude[i].value);
               
                break;
                
            }
           
        } 
    }




    for(i = 0; i < reg_lan.length; i++){
        if(reg_lan[i].checked){
            if(reg_lan[i].value==101){
                op+=10;
               
            }
          
            
            
            else{
                op+=parseInt(reg_lan[i].value);
           
                break;
               
            }
         
        } 
    }
 
    
        audit_form.overall_5.value =parseFloat((op/50)*100).toFixed(2);      
  
    overall_sc(); 
  
}

function lis_pro(){
    var listen_sk = document.getElementsByName('listen_sk');
    var comp_sk = document.getElementsByName('comp_sk');
    var pro_sk = document.getElementsByName('pro_sk');
    

    var op=0;
   
    for(i = 0; i < listen_sk.length; i++){
        if(listen_sk[i].checked){
            if(listen_sk[i].value==101){
                op+=10;
            }else{
                op+=parseInt(listen_sk[i].value);
                break;
            }
           
        } 
    }
    for(i = 0; i < comp_sk.length; i++){
        if(comp_sk[i].checked){
            if(comp_sk[i].value==101){
                op+=10;
            }else{
                op+=parseInt(comp_sk[i].value);
                break;
            }
         
        } 
    }
    for(i = 0; i < pro_sk.length; i++){
        if(pro_sk[i].checked){
        
            if(pro_sk[i].value==101){
                op+=10;
            }else{
                op+=parseInt(pro_sk[i].value);
                break;
            }
        
        }
    }
    
    audit_form.overall_4.value =parseFloat((op/30)*100).toFixed(2);
    overall_sc();
}




    function call_eqt(){
        var approp = document.getElementsByName('approp');
        var ho_mu = document.getElementsByName('ho_mu');
        var call_pers = document.getElementsByName('call_pers');
        var automation_R = document.getElementsByName('automation_R');
        var ticket_no_call = document.getElementsByName('ticket_no_call');
        var call_closed = document.getElementsByName('call_closed');
        

        var op=0;
       
        for(i = 0; i < approp.length; i++){
            if(approp[i].checked){
                if(approp[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(approp[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < ho_mu.length; i++){
            if(ho_mu[i].checked){
                if(ho_mu[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(ho_mu[i].value);
                    break;
                }
             
            } 
        }
        for(i = 0; i < call_pers.length; i++){
            if(call_pers[i].checked){
            
                if(call_pers[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(call_pers[i].value);
                    break;
                }
            
            }
        }
        for(i = 0; i < automation_R.length; i++){
            if(automation_R[i].checked){
            
                if(automation_R[i].value==101){
                    op+=10;
                   
                }
                
                else{
                    op+=parseInt(automation_R[i].value);
                   
                    break;
                }
            
            }
        }
        for(i = 0; i < ticket_no_call.length; i++){
            if(ticket_no_call[i].checked){
            
                if(ticket_no_call[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(ticket_no_call[i].value);
                    break;
                }
            
            }
        }
        for(i = 0; i < call_closed.length; i++){
            if(call_closed[i].checked){
            
                if(call_closed[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(call_closed[i].value);
                    break;
                }
            
            }
        }
        
        audit_form.overall_3.value =parseFloat((op/60)*100).toFixed(2);
        overall_sc();
    }
   
   
   
   
   
   function satis_qu(){
        var pro= document.getElementsByName('pro');
        var speech= document.getElementsByName('speech');
        var rate= document.getElementsByName('rate');
        var flu= document.getElementsByName('flu');
        var tone= document.getElementsByName('tone');
        var gram= document.getElementsByName('gram');
        var op=0;
        for(i = 0; i < pro.length; i++){
            if(pro[i].checked){
                if(pro[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(pro[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < speech.length; i++){
            if(speech[i].checked){
                if(speech[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(speech[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < rate.length; i++){
            if(rate[i].checked){
                if(rate[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(rate[i].value);
                    break;
                }
               
            } 
        }

        for(i = 0; i < flu.length; i++){
            if(flu[i].checked){
                if(flu[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(flu[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < tone.length; i++){
            if(tone[i].checked){
                if(tone[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(tone[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < gram.length; i++){
            if(gram[i].checked){
                if(gram[i].value==101){
                    op+=10;
                }
                else{
                    op+=parseInt(gram[i].value);
                    break;
                }
               
            } 
        }
        audit_form.overall_1.value =parseFloat((op/60)*100).toFixed(2);
        overall_sc();




    }

    function courtesy_op(){
        var courtesy = document.getElementsByName('court_Pro');
        var empathy = document.getElementsByName('emp_own');
        var guide = document.getElementsByName('guide_ins');
        

        var op=0;
       
        for(i = 0; i < courtesy.length; i++){
            if(courtesy[i].checked){
                if(courtesy[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(courtesy[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < empathy.length; i++){
            if(empathy[i].checked){
                if(empathy[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(empathy[i].value);
                    break;
                }
             
            } 
        }
        for(i = 0; i < guide.length; i++){
            if(guide[i].checked){
            
                if(guide[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(guide[i].value);
                    break;
                }
            
            }
        }
        
        audit_form.overall_2.value =parseFloat((op/30)*100).toFixed(2);
        overall_sc();
    }

    function overall_sc(){   
       

     
      
            v1 = parseFloat(audit_form.overall_1.value);
            v2 = parseFloat(audit_form.overall_2.value);
              v3 = parseFloat(audit_form.overall_3.value);
              v4 = parseFloat(audit_form.overall_4.value);
              v5 = parseFloat(audit_form.overall_5.value);
          val2=  audit_form.overall_score.value =parseFloat((v1 + v2+v3+v4+v5)/5).toFixed(2);
          check_color(val2);

    }

        
          function check_color(val){
          if(val==100){
            document.getElementById('alert').innerHTML="BLUE ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "blue"; 
            

          }
          else if(val>=90 && val<100 ){
            document.getElementById('alert').innerHTML="GREEN ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "green"; 
            

          }
          else if(val>=80 && val<90 ){
            document.getElementById('alert').innerHTML="AMBER ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "#ffbf00"; 
            

          }
          else if(val<80 && val>0 ){
            document.getElementById('alert').innerHTML="RED ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "red"; 
            

          }



          else if(val==0){
            document.getElementById('alert').innerHTML="FATAL ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "red"; 

          }
          

        }   
    
    

    function get_emp_id(){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                audit_form.emp_id.value = this.responseText;
            }
            
        };
        xmlhttp.open("GET", "getempid.php?name=" + audit_form.eng_name.value, true);
        xmlhttp.send();
    }

  
