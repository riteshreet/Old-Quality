<!DOCTYPE html> 
<html> 
  
<head> 
    <title> 
        Get value of selected 
        radio button 
    </title> 
</head> 
  
<body> 
    <p> 
        Select a radio button and click on Submit. 
    </p> 
      
    pronounciation: 
    <input type="radio" name="pro" value="10">Excellent
    <input type="radio" name="pro" value="10">NA
    <input type="radio" name="pro" value="">Good 
    <br>


    Speech Clarity: 
    <input type="radio" name="cla" value="5">Excellent
    <input type="radio" name="cla" value="4">Average 
    <input type="radio" name="cla" value="3">Good 
    <br>

    Rate of speech: 
    <input type="radio" name="spe" value="5">Excellent
    <input type="radio" name="spe" value="4">Average 
    <input type="radio" name="spe" value="3">Good 
    <br>

    Fluency : 
    <input type="radio" name="flu" value="5">Excellent
    <input type="radio" name="flu" value="4">Average 
    <input type="radio" name="flu" value="3">Good 
    <br>
    Tone : 
    <input type="radio" name="ton" value="5">Excellent
    <input type="radio" name="ton" value="4">Average 
    <input type="radio" name="ton" value="3">Good 
    <br>
    grammar : 
    <input type="radio" name="gra" value="5">Excellent
    <input type="radio" name="gra" value="4">Average 
    <input type="radio" name="gra" value="3">Good 
    <br>


    

      
    <button type="button" onclick="displayRadioValue()"> 
        Submit 
    </button> 
      
    <br> 

    <div id ="display"></div>
    <input type="text" id="result" value="" >
      
    
      
    <script> 
        function displayRadioValue() {

            var sum=0;


            document.getElementById("display").innerHTML = ""; 
            var ele = document.getElementsByTagName('input'); 
              
            for(i = 0; i < ele.length; i++) { 
                  
                if(ele[i].type="radio") { 
                  
                    if(ele[i].checked) {

                   
                        document.getElementById("display").innerHTML 
                                += ele[i].name + " Value: " 
                                + ele[i].value + "<br>"; 
                             
                              var  a= Number(ele[i].value);
                           
                              sum= sum +a;
                            
                             
                    }


                               
                }

            }
            document.getElementById("result").value=sum;
            console.log(sum);
          




        }
    </script> 
</body> 
</html> 