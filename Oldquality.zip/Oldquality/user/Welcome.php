<?php  
session_start();  
  
if(!$_SESSION['email_user'])  
{  
  
    header("Location: login.php");//redirect to login page to secure the welcome page without login access.  
}  

  
?>  
  
  <!DOCTYPE html>
<html lang="en">
<head>


  <title>User Audit Portal</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
.container {
  padding: 2rem 0rem;
}

h4 {
  margin: 2rem 0rem 1rem;
}

.table-image td, .table-image th {
  vertical-align: middle;
  width: 20px;
 
 

}
.w-12{
  height: 20px;
  width: 30%;
 
 

}
.button {
  padding: 12px 15px;
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

</style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../index.php">Audit Portal</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
     
      <li><a href="../view/search_emp.php">View</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">

    <li> <a href="#"><?php echo $_SESSION['name_user'];?></a></li>
      <li><a href="Logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
     
    </ul>
  </div>
</nav>
  
<div class="container">
  <div class="row">
    <div class="col-12">
		<table class="table table-image">
		  <thead>
		    <tr>
		      <th scope="col">Sl No</th>
		      <th scope="col">Line of Bussiness</th>
		      <th scope="col">Bussiness Details</th>
		      <th scope="col">Call Audit</th>
		     <th scope="col">Process Audit</th>
		     
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <th scope="row">1</th>
		      <td class="w-12">
			      <img src="../Bissell.png" class="img-fluid img-thumbnail" alt="Sheep"style="width: 280px;height:120px"  >
		      </td>
		      <td >Bissell Inc., also known as Bissell Homecare, is an American privately owned vacuum cleaner and floor care product manufacturing corporation headquartered in Walker, Michigan in Greater Grand Rapids.</td>
          <td><button class="button" onclick="location.href='../forms/Bissel/call/BISSELL.php'">Call Audit</button></td>
		      <td><button class="button"onclick="location.href='../forms/Bissel/process/BISSELL_P.php'">Process Audit</button></td>
		   
		    </tr>
		    <tr>
		      <th scope="row">2</th>
		      <td class="w-12">
			      <img src="../Dialog.png" class="img-fluid img-thumbnail" alt="Sheep"style="width: 280px;height:120px" >
		      </td>
		      <td>Dialog Semiconductor PLC is a UK-based manufacturer of semiconductor based system solutions[clarification needed]. The company is headquartered in the United Kingdom in Reading, with a global sales, R&D and marketing organization. Dialog creates highly integrated application-specific standard product (ASSP) and application-specific integrated circuit (ASIC) mixed-signal integrated circuits (ICs), optimised for smartphones, computing, Internet of Things devices, LED solid-state lighting (SSL), and smart home applications.</td>
		      <td><button class="button"onclick="location.href='../forms/Dialog/call/DIALOG.php'">Call Audit</button></td>
		      <td><button class="button"onclick="location.href='../forms/Dialog/process/DIALOG_P.php'">Process Audit</button></td>
		    
        </tr>
        <tr>
		      <th scope="row">2</th>
		      <td class="w-12">
			      <img src="../GameStop.png" class="img-fluid img-thumbnail" alt="Sheep" style="width: 280px;height:120px">
		      </td>
		      <td>GameStop Corp. (better known simply as GameStop) is an American video game, consumer electronics and gaming merchandise retailer. The company is headquartered in Grapevine, Texas, United States, a suburb of Dallas, and operates 5,830 retail stores throughout the United States, Canada, Australia, New Zealand, and Europe. The company's retail stores primarily operate under the GameStop, EB Games, ThinkGeek and Micromania-Zing brands</td>
          <td><button class="button"onclick="location.href='../forms/Game/call/GAME_STOP.php'">Call Audit</button></td>
		      <td><button class="button"onclick="location.href='../forms/Game/process/GAME_STOP_P.php'">Process Audit</button></td>
		     
        </tr>
         <tr>
		      <th scope="row">2</th>
		      <td class="w-12">
			      <img src="../lincoln.png" class="img-fluid img-thumbnail" alt="Sheep" style="width: 280px;height: 120px">
		      </td>
		      <td>Lincoln National Corporation is a Fortune 250 American holding company, which operates multiple insurance and investment management businesses through subsidiary companies. Lincoln Financial Group is the marketing name for LNC and its subsidiary companies.
LNC was organized under the laws of the state of Indiana in 1968, and maintains its principal executive offices in Radnor, Pennsylvania. The company traces its roots to its earliest predecessor founded in 1905.</td>
          <td><button class="button" onclick="location.href='../forms/LFG/call/LFG.php'">Call Audit</button></td>
          <td><button class="button" >Testing page </button></td>
           <td><button class="button"onclick="location.href='../forms/LFG/process/LFG_P.php'">Process Audit</button></td>
           
		   
		    </tr>
		  </tbody>
		</table>   
    </div>
  </div>
</div>

</body>
</html>