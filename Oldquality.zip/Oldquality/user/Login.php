

    <?php  
    session_start();//session starts here  
    if(isset($_SESSION['email_user'])){
        header('location:Welcome.php');
    }
    
    
    ?>  
  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>



 <div class="main" style="padding-bottom: 25px;">


  <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                        <a href="Registration.php" class="signup-image-link">Create an account</a>
                    </div>

                    <div class="signin-form">
                        <h2 class="form-title">Sign In</h2>
                        <form method="POST"action="login.php" class="register-form" id="login-form"  >
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-email"></i></label>
                                <input  placeholder="E-mail" name="email" type="email"/>
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password"/>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="login" id="signin" class="form-submit" value="Log in"/>
                            </div>
                        </form>
                       
                    </div>
                </div>
            </div>
        </section>
		
		</div>
		
		
		 <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>




<?php  
  
include("dbconn.php");  
  
if(isset($_POST['login']))  
{  
    $user_email=$_POST['email'];  
    $user_pass=$_POST['pass'];  
  
    $check_user="SELECT * FROM `user_login` WHERE `EMAIL`='$user_email' AND `PASS`='$user_pass'";  
  
    $run=mysqli_query($conn,$check_user);  
    $row=mysqli_num_rows($run);
  
    if($row==1)  
    {  
        $data=mysqli_fetch_assoc($run);
        $user_name=$data['NAME'];
        $user_mid=$data['MID'];
        
        $_SESSION['user_mid']=$user_mid;
        $_SESSION['name_user']=$user_name;//here session is used and value of $user_email store in $_SESSION. 
        $_SESSION['email_user']=$user_email;//here session is used and value of $user_email store in $_SESSION. 
        
        header('location:Welcome.php');
  
    }  
    else  
    {  
      echo "<script>alert('Email or password is incorrect!')</script>";  
    }  
}  
?> 