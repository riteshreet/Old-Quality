<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up </title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="main">

        <!-- Sign up form -->
        <section class="signup">
            <div class="container">
                <div class="signup-content">
                    <div class="signup-form">
                        <h2 class="form-title">Sign up</h2>
                        <form method="POST" class="register-form" action="Registration.php" id="register-form">
                            <div class="form-group">
                                <label for="MID"><i class="zmdi zmdi-card"></i></label>
                                <input type="text" name="mid" id="name" placeholder="MID: M1055567" required/>
                            </div> 
							<div class="form-group">
                                <label for="name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="name" id="name" placeholder="Your Name" required/>
                            </div>
                            <div class="form-group">
                                <label for="email"><i class="zmdi zmdi-email"></i></label>
                                <input type="email" name="email" id="email" placeholder="Your Email"required/>
                            </div>
                            <div class="form-group">
                                <label for="pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="pass" id="pass" placeholder="Password" required/>
                            </div>
                            <div class="form-group">
                                <label for="re-pass"><i class="zmdi zmdi-lock-outline"></i></label>
                                <input type="password" name="re_pass" id="re_pass" placeholder="Repeat your password" required/>
                            </div>
                            
                            <div class="form-group form-button">
                                <input type="submit" name="register" id="signup" class="form-submit" value="Register"/>
                            </div>
                        </form>
                    </div>
                    <div class="signup-image">
                        <figure><img src="images/signup-image.jpg" alt="sing up image"></figure>
                        <a href="Login.php" class="signup-image-link">I am already member</a>
                    </div>
                </div>
            </div>
        </section>

       

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>



<?php  
  
include("dbconn.php");//make connection here  
if(isset($_POST['register']))  
{   $user_mid=mysqli_real_escape_string($conn,$_POST['mid']);
    $user_name=mysqli_real_escape_string($conn,$_POST['name']);//here getting result from the post array after submitting the form.  
    $user_pass=mysqli_real_escape_string($conn,$_POST['pass']);//same  
    $user_email=mysqli_real_escape_string($conn,$_POST['email']);//same  
    $user_re_pass=mysqli_real_escape_string($conn,$_POST['re_pass']);//same  
  
  
    if($user_name=='')  
    {  
        //javascript use for input checking  
        echo"<script>alert('Please enter the name')</script>";  
exit();//this use if first is not work then other will not show  
    }  
    if(strlen($user_mid)!==8)  
    {  
        //javascript use for input checking  
        echo"<script>alert('Please Enter your correct MID')</script>";  
exit();//this use if first is not work then other will not show  
    }  
  
    if(strlen($user_pass)<=6)  
    {  
        echo"<script>alert('Please enter the password more then 6 character')</script>";  
exit();  
    }  
    if($user_pass!==$user_re_pass){
        echo"<script>alert('Password does not  match ')</script>";  
        exit();  


    }
  
    if($user_email=='')  
    {  
        echo"<script>alert('Please enter the email')</script>";  
    exit();  
    }  
    if($user_mid=='')  
    {  
        echo"<script>alert('Please enter the MID which Should be  ex :M1055567')</script>";  
    exit();  
    }  
//here query check weather if user already registered so can't register again.  
    $check_email_query="SELECT * FROM `user_login` WHERE `EMAIL`='$user_email'";  
    $run_query=mysqli_query($conn,$check_email_query);  
  
    if(mysqli_num_rows($run_query)>0)  
    {  
echo "<script>alert('Email $user_email is already exist in our database, Please try another one!')</script>";  
exit();  
    }  
//insert the user into the database.  
    $insert_user="INSERT INTO `user_login`( `MID`, `NAME`, `EMAIL`, `PASS`) VALUES ('$user_mid','$user_name','$user_email','$user_pass')";  
    if(mysqli_query($conn,$insert_user))  
    {  echo"<script>alert('Registration Succesful !!!')</script>";
        echo"<script>window.open('Login.php','_self')</script>";  
    }  
  
  
  
}  
  
?>  