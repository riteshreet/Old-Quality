<?php
// start a session
session_start();
 
// manipulate session variables
?>


<?php
 

if(isset($_POST['submit'])){
    include('dbconn.php');
  
    // $emp_id=$_POST['emp_id'];
    // echo $emp_id;
    // $vip_user=$_POST['vip_user'];
    // $PID=20;
    // $auditor_mid=  $_SESSION['user_mid'];
    $eng_name=mysqli_real_escape_string($conn,$_POST['eng_name']); 
    $ticket_no=mysqli_real_escape_string($conn,$_POST['ticket_no']); 
    $vip_user=mysqli_real_escape_string($conn,$_POST['vip_user']); 
    $emp_id=mysqli_real_escape_string($conn,$_POST['emp_id']); 
    $date=mysqli_real_escape_string($conn,$_POST['date']); 
    $type_call=mysqli_real_escape_string($conn,$_POST['type_call']); 
    $call_no=mysqli_real_escape_string($conn,$_POST['call_no']); 
    $type_of_audit=mysqli_real_escape_string($conn,$_POST['type_of_audit']); 
    $Audited_by=mysqli_real_escape_string($conn,$_POST['Audited_by']); 
    $overall_score=mysqli_real_escape_string($conn,$_POST['overall_score']); 
    $level=mysqli_real_escape_string($conn,$_POST['level']); 
    $pronunciation=mysqli_real_escape_string($conn,$_POST['pronunciation']); 
    $sp_clarity=mysqli_real_escape_string($conn,$_POST['sp_clarity']); 
    $rate_speech=mysqli_real_escape_string($conn,$_POST['rate_speech']); 
    $flu=mysqli_real_escape_string($conn,$_POST['flu']); 
    $tone=mysqli_real_escape_string($conn,$_POST['tone']); 
    $gram=mysqli_real_escape_string($conn,$_POST['gram']); 
    $overall_1=mysqli_real_escape_string($conn,$_POST['overall_1']); 
    $feedback_1=mysqli_real_escape_string($conn,$_POST['feedback_1']); 
    $court_Pro=mysqli_real_escape_string($conn,$_POST['court_Pro']); 
    $emp_own=mysqli_real_escape_string($conn,$_POST['emp_own']); 
    $guide_ins=mysqli_real_escape_string($conn,$_POST['guide_ins']); 
    $overall_2=mysqli_real_escape_string($conn,$_POST['overall_2']); 
    $feedback_2=mysqli_real_escape_string($conn,$_POST['feedback_2']); 
    $call_open=$_POST['call_open']; 
    $contact_num=mysqli_real_escape_string($conn,$_POST['contact_num']); 
    $ho_mu=mysqli_real_escape_string($conn,$_POST['ho_mu']); 
    $call_pers=mysqli_real_escape_string($conn,$_POST['call_pers']); 
    $remote_R=mysqli_real_escape_string($conn,$_POST['remote_R']); 
    $pas_res_R=mysqli_real_escape_string($conn,$_POST['pas_res_R']); 
    $tran_script=mysqli_real_escape_string($conn,$_POST['tran_script']); 
    $self_service=mysqli_real_escape_string($conn,$_POST['self_service']); 
    $issue_res=mysqli_real_escape_string($conn,$_POST['issue_res']); 
    $ticket_num=mysqli_real_escape_string($conn,$_POST['ticket_num']); 
    $call_closed=mysqli_real_escape_string($conn,$_POST['call_closed']); 
    $overall_3=mysqli_real_escape_string($conn,$_POST['overall_3']); 
    $feedback_3=mysqli_real_escape_string($conn,$_POST['feedback_3']); 
    $listen=mysqli_real_escape_string($conn,$_POST['listen']); 
    $para=mysqli_real_escape_string($conn,$_POST['para']); 
    $probing=mysqli_real_escape_string($conn,$_POST['probing']); 
    $overall_4=mysqli_real_escape_string($conn,$_POST['overall_4']); 
    $feedback_4=mysqli_real_escape_string($conn,$_POST['feedback_4']); 
    $use_pro_R=mysqli_real_escape_string($conn,$_POST['use_pro_R']); 
    $reg_lan_R=mysqli_real_escape_string($conn,$_POST['reg_lan_R']); 
    $create_ticket_R=mysqli_real_escape_string($conn,$_POST['create_ticket_R']); 
    $eng_rude_R=mysqli_real_escape_string($conn,$_POST['eng_rude_R']); 
    $release_call_R=mysqli_real_escape_string($conn,$_POST['release_call_R']); 
    $overall_5=mysqli_real_escape_string($conn,$_POST['overall_5']); 
    $feedback_5=mysqli_real_escape_string($conn,$_POST['feedback_5']); 
    $auditor_mid=$_SESSION['user_mid'];
    $PID=20;
   
    
   

  
   
    $qry= "INSERT INTO `gamestop_call`( `eng_name`, `ticket_no`, `vip_user`, `emp_id`, `date`, `type_call`, `call_no`, `type_of_audit`, `Audited_by`, `overall_score`, `level`, `pronunciation`, `sp_clarity`, `rate_speech`, `flu`, `tone`, `gram`, `overall_1`, `feedback_1`, `court_Pro`, `emp_own`, `guide_ins`, `overall_2`, `feedback_2`, `call_open`, `contact_num`, `ho_mu`, `call_pers`, `remote_R`, `pas_res_R`, `tran_script`, `self_service`, `issue_res`, `ticket_num`, `call_closed`, `overall_3`, `feedback_3`, `listen`, `para`, `probing`, `overall_4`, `feedback_4`, `use_pro_R`, `reg_lan_R`, `create_ticket_R`, `eng_rude_R`, `release_call_R`, `overall_5`, `feedback_5`, `Auditor_mid`,`PID`) VALUES ('$eng_name', '$ticket_no', '$vip_user', '$emp_id', '$date', '$type_call', '$call_no', '$type_of_audit', '$Audited_by', '$overall_score', '$level', '$pronunciation', '$sp_clarity', '$rate_speech', '$flu', '$tone', '$gram', '$overall_1', '$feedback_1', '$court_Pro', '$emp_own', '$guide_ins', '$overall_2', '$feedback_2', '$call_open', '$contact_num', '$ho_mu', '$call_pers', '$remote_R', '$pas_res_R', '$tran_script', '$self_service', '$issue_res', '$ticket_num', '$call_closed', '$overall_3', '$feedback_3', '$listen', '$para', '$probing', '$overall_4', '$feedback_4', '$use_pro_R', '$reg_lan_R', '$create_ticket_R', '$eng_rude_R', '$release_call_R', '$overall_5', '$feedback_5', '$auditor_mid','$PID')";
    
    

    $run= mysqli_query($conn,$qry);
    echo "$run";
    
    if($run==true)
    {
        ?>
        <script>
                alert('Data Inserted Succesfully');
                window.open('GAME_STOP.php','_self');

        </script>

<?php

    }
}



?>
