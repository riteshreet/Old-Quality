<?php
session_start();

if(isset($_SESSION['email_user'])){

    
}
else{
    header('location:../../user/Login.php');
}



?>
<!DOCTYPE html>
<html lang="en">
<?php
include("dbconn.php");
$sql = "SELECT `MID`, `EMP_NAME` FROM `add_employee`  ";
$result = $conn->query($sql);
$map;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $map[$row['EMP_NAME']] = $row['MID'];
    }
}
?>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>GAMESTOP CALL AUDIT</title>    


  
<script type="text/javascript" src="jsfile.js"></script>
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso12.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; color: #000000}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: #ffffff !important;} .asteriskField{color: red;}


</style>
<body onload="speech_op();courtesy_op();overall_sc();get_emp_id();">
<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(187,221,189,0.549);"> 
  <form method="post" action="upload.php" name="audit_form">
   <div class="row" style="border-style:solid;border-width:2px;height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold"> Gamestop Call Audit </h4>
      </label>
     </div>	
	 </div>
	 </div>
	 <div class="row" style="border-style:solid;border-width:2px; height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold" id="alert" style="background-color: green;"> Fatal Alerts </h4>
      </label>
     </div>	
	 </div>
	 </div>   
	<div class="row" style="border-style:solid;border-width:2px">
	<div class="col-md-3 " >
     <div class="form-group"  >
	 
      <label class="control-label requiredField" for="eng_name" name="eng_name_label">
       Engineer Name :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="eng_name" name="eng_name" onchange="get_emp_id()" >
        <?php
            foreach($map as $name => $roll )
                echo "<option>".$name."</option>";
        ?>
      </select>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="ticket_no">
       Ticket Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="ticket_no" name="ticket_no" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="vip_user">
       Is a VIP User :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="vip_user" name="vip_user">
       <option value="Yes">
        Yes
       </option>
       <option value="No">
        No
       </option>
      </select>
     </div>
    </div>
    <!-- =====================================================Section 1============================================================== -->
  
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="emp_id">
       Employee ID :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="emp_id" name="emp_id" type="text"/>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="date">
       Audit Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
	<div class="form-group ">
      <label class="control-label requiredField" for="type_call">
       Type of call :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="type_call" name="type_call">
       <option value="Inbound_call">
        Inbound call
       </option>
       <option value="Outbound_call">
        Outbound Call
       </option>
	   </option>
      </select>
     </div> 
    </div>
	
	<!-- =====================================================Section 2============================================================== -->
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="call_no">
       Call Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="call_no" name="call_no" type="text"/>
     </div>
	 <div class="form-group ">
      <label class="control-label requiredField" for="type_of_audit">
       Type of Audit :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="type_of_audit" name="type_of_audit">
       <option value="recorded_call">
        Recorded call
       </option>
       <option value="live_call">
        Live Call
       </option>
	   </option>
       <option value="tickets">
        Tickets
       </option>
      </select>
     </div>  
 <div class="form-group ">
      <label class="control-label requiredField" for="Audited_by">
       Audited by :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Audited_by" name="Audited_by" type="text"/>
     </div>     
    </div>

   <!-- =====================================================Section 3============================================================== -->
   <div class="col-md-3 " >
  
      <div class="form-group">
      <label class="control-label requiredField" for="overall_score">
       Overall Score :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="overall_score" name="overall_score" type="text" >
     </div>
	 
      <div class="form-group ">
      <label class="control-label requiredField" for="level">
       Level :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="level" name="level" type="text" >
     </div>
    </div>
   </div>
    <!-- =====================================================Section 4============================================================== -->
	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Speech </h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="pronunciation" name="pronunciation">
       Pronunciation :
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp_clarity" name="sp_clarity">
       Speech Clarity :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="rate_speech" name="rate_speech">
       Rate of Speech :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="flu" name="flu">
       Fluency :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="tone" name="tone">
       Tone :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="gram" name="gram">
       Grammar :
      </label>
     </div>	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="pronunciation" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="pronunciation" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="pronunciation" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="pronunciation" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="sp_clarity" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="sp_clarity" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="sp_clarity" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="sp_clarity" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="rate_speech" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="rate_speech" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="rate_speech" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="rate_speech" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="flu" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="flu" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="flu" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="flu" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="tone" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="tone" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="tone" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="tone" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="gram" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="gram" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="gram" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="gram" value="10" checked onclick="speech_op()">
     <label for="male">NA</label>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_1" name="overall_1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_1"name="feedback_1" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
 
 <!-- =====================================================Section 4============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Courtesy and Empathy </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="court_Pro" name="court_Pro">
       Courtesy and Professionalism :
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="emp_own" name="emp_own">
       Empathy and Ownership :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="guide_ins" name="guide_ins">
       Guiding And Instructing the customer :
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="court_Pro" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="court_Pro" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="court_Pro" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="court_Pro" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="emp_own" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="emp_own" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="emp_own" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="emp_own" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="guide_ins" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="guide_ins" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="guide_ins" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="guide_ins" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_2" name="overall_2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_2"name="feedback_2" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
   <!-- =====================================================Section 5============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Call Etiquette </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="call_open" name="call_open">
      Was the call opening appropriate?
      </label>
	 </div>	 
	  <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="contact_num" name="contact_num">
     Did the engineer confirm the contact number of the client?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="ho_mu" name="ho_mu">
     Were hold/mute and transfer procedures used appropriately?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="call_pers" name="call_pers">
      Was the call personalized?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="remote_R" name="remote_R" style="color:red">
      Did the engineer provide disclaimer before taking remote of the computer ?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="pas_res_R" name="pas_res_R" style="color:red">
     Did the engineer follow the password reset\unlock policy?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="tran_script" name="tran_script">
      Did the engineer follow the proper transfer script(Warm Tranfer)?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="self_service" name="self_serviceservice">
    Did the technician help the user understand the usage of self-service portals and automation for generic application usage?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="issue_res" name="issue_res">
      Did the engineer confirm the issue resolution?
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="ticket_num" name="ticket_num">
     Did the technician attempt to provide the ticket number on call? 
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="call_closed" name="call_closed">
     Was the call closed appropriately? OR Asked for further assistance? 
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <br>
	 <input type="radio" id="yes" name="call_open" value="10"  onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_open" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_open" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="contact_num" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="contact_num" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="contact_num" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="ho_mu" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="ho_mu" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="ho_mu" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="call_pers" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_pers" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_pers" value="10"  onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="remote_R" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="remote_R" value="0"  onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="remote_R" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="pas_res_R" value="yes" onclick="overall_sc();">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="pas_res_R" value="no" onclick="overall_sc();">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="pas_res_R" value="na" onclick="overall_sc();">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="tran_script" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="tran_script" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="tran_script" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="yes" name="self_service" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="self_service" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="self_service" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="yes" name="issue_res" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="issue_res" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="issue_res" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="yes" name="ticket_num" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="ticket_num" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="ticket_num" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="yes" name="call_closed" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_closed" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_closed" value="na">
     <label for="male">NA</label> <br><br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_3" name="overall_3" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_3"name="feedback_3" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 6============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Listening and Probing </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="listen" name="listen">
       Listening Skills?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="para" name="para">
       Comprehension and Paraphrasing :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="probing" name="probing">
       Probing?
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="listen" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="listen" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="listen" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="listen" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="para" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="para" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="para" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="para" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="probing" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="probing" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="probing" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="probing" value="na">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_4" name="overall_4" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
      <textarea id="feedback_4"name="feedback_4" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 7============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Inappropriate Behaviour</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="use_pro_R" name="use_pro_R" style="color:red">
       Did the engineer use Profanity on the call?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="reg_lan_R" name="reg_lan_R" style="color:red">
       Did the engineer use any regional language?
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="create_ticket_R" name="create_ticket_R" style="color:red">
       Did the engineer create a ticket for this conversation?
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="eng_rude_R" name="eng_rude_R" style="color:red">
       Was the engineer rude on the call?
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="release_call_R" name="release_call_R" style="color:red">
       Did the engineer release the call without the user's permission?
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="yes" name="use_pro_R" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="use_pro_R" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="use_pro_R" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="reg_lan_R" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="reg_lan_R" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="reg_lan_R" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="create_ticket_R" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="create_ticket_R" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="create_ticket_R" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="eng_rude_R" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="eng_rude_R" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="eng_rude_R" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="release_call_R" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="release_call_R" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="release_call_R" value="na">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_5" name="overall_5" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_5"name="feedback_5" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div><br>
 
    <div class="col-md-12">
     <div class="form-group" align="center">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
       <!-- <button class="btn btn-info btn-sm"  onclick="myfunction()">
        send 
       </button> -->
      </div>
     </div>
	 </div>
	 
</form>
</div>


<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>



</body>

<html>