<?php
// start a session
session_start();
 
// manipulate session variables
?>


<?php
 

if(isset($_POST['submit'])){
    include('dbconn.php');
  
    // $emp_id=$_POST['emp_id'];
    // echo $emp_id;
    // $vip_user=$_POST['vip_user'];
    $PID=20;
    $auditor_mid=  $_SESSION['user_mid'];
    $eng_name=mysqli_real_escape_string($conn,$_POST['eng_name']); 
    $ticket_no=mysqli_real_escape_string($conn,$_POST['ticket_no']); 
    $Incident_priority=mysqli_real_escape_string($conn,$_POST['Incident_priority']); 
    $emp_id=mysqli_real_escape_string($conn,$_POST['emp_id']); 
    $date=mysqli_real_escape_string($conn,$_POST['date']); 
    $inc_date=mysqli_real_escape_string($conn,$_POST['inc_date']); 
    $Resolver_group=mysqli_real_escape_string($conn,$_POST['Resolver_group']); 
    $Ticket_status=mysqli_real_escape_string($conn,$_POST['Ticket_status']); 
    $Audited_by=mysqli_real_escape_string($conn,$_POST['Audited_by']); 
    $Audit_score=mysqli_real_escape_string($conn,$_POST['Audit_score']); 
    $level=mysqli_real_escape_string($conn,$_POST['level']); 
    $response_R=mysqli_real_escape_string($conn,$_POST['response_R']); 
    $rel_ticket=mysqli_real_escape_string($conn,$_POST['rel_ticket']); 
    $cor_case=mysqli_real_escape_string($conn,$_POST['cor_case']); 
    $ser_cat_R=mysqli_real_escape_string($conn,$_POST['ser_cat_R']); 
    $priority=mysqli_real_escape_string($conn,$_POST['priority']); 
    $inc_state_R=mysqli_real_escape_string($conn,$_POST['inc_state_R']); 
    $pending_reason_R=mysqli_real_escape_string($conn,$_POST['pending_reason_R']); 
    $remote_script_R=mysqli_real_escape_string($conn,$_POST['remote_script_R']); 
    $escalate=mysqli_real_escape_string($conn,$_POST['escalate']); 
    $overall_1=mysqli_real_escape_string($conn,$_POST['overall_1']); 
    $feedback_1=mysqli_real_escape_string($conn,$_POST['feedback_1']); 
    $des_appr=mysqli_real_escape_string($conn,$_POST['des_appr']); 
    $issue=mysqli_real_escape_string($conn,$_POST['issue']); 
    $call_source_R=mysqli_real_escape_string($conn,$_POST['call_source_R']); 
    $vital_inf=mysqli_real_escape_string($conn,$_POST['vital_inf']); 
    $troubleshooting=mysqli_real_escape_string($conn,$_POST['troubleshooting']); 
    $cor_temp=mysqli_real_escape_string($conn,$_POST['cor_temp']); 
    $followed=mysqli_real_escape_string($conn,$_POST['followed']); 
    $prop_process=mysqli_real_escape_string($conn,$_POST['prop_process']); 
    $summary=mysqli_real_escape_string($conn,$_POST['summary']); 
    $Knowledge_base=mysqli_real_escape_string($conn,$_POST['Knowledge_base']); 
    $overall_2=mysqli_real_escape_string($conn,$_POST['overall_2']); 
    $feedback_2=mysqli_real_escape_string($conn,$_POST['feedback_2']); 
    $resolve=mysqli_real_escape_string($conn,$_POST['resolve']); 
    $explain_resolution=mysqli_real_escape_string($conn,$_POST['explain_resolution']); 
    $selfservice_automation=mysqli_real_escape_string($conn,$_POST['selfservice_automation']); 
    $user_confirmation=mysqli_real_escape_string($conn,$_POST['user_confirmation']); 
    $overall_3=mysqli_real_escape_string($conn,$_POST['overall_3']); 
    $feedback_3=mysqli_real_escape_string($conn,$_POST['feedback_3']); 
    $progress=mysqli_real_escape_string($conn,$_POST['progress']); 
    $strike_3_R=mysqli_real_escape_string($conn,$_POST['strike_3_R']); 
    $overall_4=mysqli_real_escape_string($conn,$_POST['overall_4']); 
    $feedback_4=mysqli_real_escape_string($conn,$_POST['feedback_4']); 
    $Auditor_mid=mysqli_real_escape_string($conn,$_POST['Auditor_mid']); 
   
   
    $qry= "INSERT INTO `gamestop_process`( `eng_name`, `ticket_no`, `Incident_priority`, `emp_id`, `date`, `inc_date`, `Resolver_group`, `Ticket_status`, `Audited_by`, `Audit_score`, `level`, `response_R`, `rel_ticket`, `cor_case`, `ser_cat_R`, `priority`, `inc_state_R`, `pending_reason_R`, `remote_script_R`, `escalate`, `overall_1`, `feedback_1`, `des_appr`, `issue`, `call_source_R`, `vital_inf`, `troubleshooting`, `cor_temp`, `followed`, `prop_process`, `summary`, `Knowledge_base`, `overall_2`, `feedback_2`, `resolve`, `explain_resolution`, `selfservice_automation`, `user_confirmation`, `overall_3`, `feedback_3`, `progress`, `strike_3_R`, `overall_4`, `feedback_4`, `Auditor_mid`, `PID`) VALUES ('$PID','$eng_name', '$ticket_no', '$Incident_priority', '$emp_id', '$date', '$inc_date', '$Resolver_group', '$Ticket_status', '$Audited_by', '$Audit_score', '$level', '$response_R', '$rel_ticket', '$cor_case', '$ser_cat_R', '$priority', '$inc_state_R', '$pending_reason_R', '$remote_script_R', '$escalate', '$overall_1', '$feedback_1', '$des_appr', '$issue', '$call_source_R', '$vital_inf', '$troubleshooting', '$cor_temp', '$followed', '$prop_process', '$summary', '$Knowledge_base', '$overall_2', '$feedback_2', '$resolve', '$explain_resolution', '$selfservice_automation', '$user_confirmation', '$overall_3', '$feedback_3', '$progress', '$strike_3_R', '$overall_4', '$feedback_4', '$Auditor_mid')";
    
    $run= mysqli_query($conn,$qry);
    
    if($run==true)
    {
        ?>
        <script>
                alert('Data Inserted Succesfully');
                window.open('BISSELL_P.php','_self');

        </script>

<?php

    }
}



?>
