
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>GMAESTOP CALL AUDIT</title>    


  
<script type="text/javascript" src="jsfile.js"></script>
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso12.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; color: #000000}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: #ffffff !important;} .asteriskField{color: red;}


</style>
<body onload="speech_op();courtesy_op();overall_sc();get_emp_id();">
<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(187,221,189,0.549);"> 
  <form method="post" action="upload.php" name="audit_form">
   <div class="row" style="border-style:solid;border-width:2px;height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold"> Gamestop Process Audit </h4>
      </label>
     </div>	
	 </div>
	 </div>
	 <div class="row" style="border-style:solid;border-width:2px; height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold" id="alert" style="background-color: green;">BLUE ALERTS </h4>
      </label>
     </div>	
	 </div>
	 </div>   
	<div class="row" style="border-style:solid;border-width:2px">
	<div class="col-md-3 " >
     <div class="form-group"  >
	 
      <label class="control-label requiredField" for="eng_name" name="eng_name">
       Engineer Name :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="eng_name" name="eng_name" onchange="get_emp_id()" >
        <?php
            foreach($map as $name => $roll )
                echo "<option>".$name."</option>";
        ?>
      </select>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="ticket_no">
       Ticket Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="ticket_no" name="ticket_no" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="Incident_priority">
       Incident priority :
       <span class="asteriskField">
        *
       </span>
      </label>
       <input class="form-control" id="Incident_priority" name="Incident_priority" type="text"/>
     </div>
    </div>
    <!-- =====================================================Section 1============================================================== -->
  
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="emp_id">
       Employee ID :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="emp_id" name="emp_id" type="text"/>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="date">
        Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
	 <div class="form-group ">
      <label class="control-label requiredField" for="inc_date">
        Incident logged Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="inc_date" name="inc_date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
    </div>
	
	<!-- =====================================================Section 2============================================================== -->
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="Resolver_group">
       Resolver group:
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Resolver_group" name="Resolver_group" type="text"/>
     </div>
	 <div class="form-group ">
      <label class="control-label requiredField" for="Ticket_status">
       Ticket Status:
       <span class="asteriskField">
        *
       </span>
      </label>
     <input class="form-control" id="Ticket_status" name="Ticket_status" type="text"/>
     </div> 
<div class="form-group ">
      <label class="control-label requiredField" for="Audited_by">
       Audited by:
       <span class="asteriskField">
        *
       </span>
      </label>
     <input class="form-control" id="Audited_by" name="Audited_by" type="text"/>
     </div> 	 
    </div>

   <!-- =====================================================Section 3============================================================== -->
   <div class="col-md-3 " >
  
      <div class="form-group">
      <label class="control-label requiredField" for="Audit_score">
       Audit Score :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Audit_score" name="Audit_score" type="text" >
     </div>
	 
      <div class="form-group ">
      <label class="control-label requiredField" for="level">
       Level :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="level" name="level" type="text" >
     </div>
    </div>
   </div>
    <!-- =====================================================Section 4============================================================== -->
	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="pro_meth" name="pro_meth">
       <h4 style="font-weight:bold">Process methodology</h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="response_R" name="response_R" style="color:red">
       Did the engineer meet the first response SLA and changed the status of the ticket from assigned within 30mins? (Call):
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="rel_ticket" name="rel_ticket">
       Were the relevent tickets linked? (MI;Duplicate;Child) :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_case" name="cor_case">
     Did the Engineer choose correct Case Type? (Incident/SR) :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="ser_cat_R" name="ser_cat_R" style="color:red">
      Did the Engineer choose the correct  service,category and subcategory ? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="priority" name="priority">
    Did the Engineer choose the correct Priority?  :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="inc_state_R" name="inc_state_R" style="color:red">
       Did the Engineer choose the correct incident state(New/Assigned/In Progress/Pending/Resolved/Re-assigned)?:
      </label>
     </div>	 
	  <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="pending_reason_R" name="pending_reason_R" style="color:red">
       Did the Engineer choose the right 'Pending Reason' when the ticket is kept on Hold?:
      </label>
     </div>
    <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="remote_script_R" name="remote_script_R" style="color:red">
       Was the remote script followed before taking a remote?:
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="escalate" name="escalate">
       Did the Engineer Route/escalate the ticket to the correct resolver group, if required?:
      </label>
     </div>	
	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="response_R" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="response_R" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="response_R" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="rel_ticket" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="rel_ticket" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="rel_ticket" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="cor_case" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="cor_case" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="cor_case" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="ser_cat_R" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="ser_cat_R" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="ser_cat_R" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br>
	  
	 <input type="radio" id="exc" name="priority" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="priority" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="priority" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br>
	  
	  <input type="radio" id="exc" name="inc_state_R" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="inc_state_R" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="inc_state_R" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="pending_reason_R" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="pending_reason_R" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="pending_reason_R" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="remote_script_R" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="remote_script_R" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="remote_script_R" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="escalate" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="escalate" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="escalate" value="10" checked onclick="speech_op()">
     <label for="male">NA</label><br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_1" name="overall_1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
   <textarea id="feedback_1"name="feedback_1" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
 
 <!-- =====================================================Section 4============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Documentation</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="des_appr" name="des_appr">
       Did the engineer update the short description appropriately?:
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="issue" name="issue">
       Did the engineer mention the exact issue in the description tab ? :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="call_source_R" name="call_source_R" style="color:red">
       Did the engineer choose correct Call Source in Cherwell?:
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="vital_inf" name="vital_inf">
      Did the engineer capture all the vital information? (Error screenshot if available,contact number):
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="troubleshooting" name="troubleshooting">
    Did the engineer capture detailed documentation of troubleshooting steps?:
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_temp" name="cor_temp">
    Did the engineer use correct templates? (Email; Triage/Escalation):
      </label>
     </div>
	  <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="followed" name="followed">
   Was the ticket followed-up and documented  in a timely manner? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="prop_process" name="prop_process">
   Did the engineer follow proper process to re-enable the account ? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="summary" name="summary">
   Did the engineer update relevant summary of the resolution under resolution notes?  :
      </label>
     </div>
	  <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="Knowledge_base" name="Knowledge_base">
 Did the engineer update the reference of Knowledge Base/SOP in the ticket?If there is no Knowledge Base/SOP available for that issue,a note regarding the same should be updated in the work notes. :
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="des_appr" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="des_appr" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="des_appr" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="issue" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="issue" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="issue" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="exc" name="call_source_R" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="call_source_R" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="call_source_R" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	  <input type="radio" id="exc" name="vital_inf" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="vital_inf" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="vital_inf" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	  <input type="radio" id="exc" name="troubleshooting" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="troubleshooting" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="troubleshooting" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	  <input type="radio" id="exc" name="cor_temp" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="cor_temp" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="cor_temp" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="exc" name="followed" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="followed" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="followed" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="exc" name="prop_process" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="prop_process" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="prop_process" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br><br>
	 
	  <input type="radio" id="exc" name="summary" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="summary" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="summary" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br><br>
	 
	 <input type="radio" id="exc" name="Knowledge_base" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="Knowledge_base" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="Knowledge_base" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_2" name="overall_2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_2"name="feedback_2" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
   <!-- =====================================================Section 5============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Resolution and closure</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="resolve" name="resolve">
      Was the technician able to resolve the issue?
      </label>
	 </div>	 
	  <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="explain_resolution" name="explain_resolution">
     Did the technician explain the resolution provided to the user?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="selfservice_automation" name="selfservice_automation">
     Did the technician help the user understand the usage of self-service portals and automation for generic application usage?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="user_confirmation" name="user_confirmation">
      Did the technician get confirmation from the user before closing the issue?
      </label>
	 </div>	 	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <br>
	 <input type="radio" id="yes" name="resolve" value="10"  onclick="call_eqt()">
     <label for="male">YES</label>
	 <input type="radio" id="no" name="resolve" value="0" onclick="call_eqt()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="resolve" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="explain_resolution" value="10" onclick="call_eqt()">
     <label for="male">YES</label>
	 <input type="radio" id="no" name="explain_resolution" value="0" onclick="call_eqt()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="explain_resolution" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="yes" name="selfservice_automation" value="10" onclick="call_eqt()">
     <label for="male">YES</label>
	 <input type="radio" id="no" name="selfservice_automation" value="0" onclick="call_eqt()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="selfservice_automation" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br><br><br>
	 
	 <input type="radio" id="yes" name="user_confirmation" value="10" onclick="call_eqt()">
     <label for="male">YES</label>
	 <input type="radio" id="no" name="user_confirmation" value="0" onclick="call_eqt()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="user_confirmation" value="10"  onclick="call_eqt()">
     <label for="male">NA</label> <br><br><br>	
	 
	 
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_3" name="overall_3" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_3"name="feedback_3" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 6============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Customer Expectation Management</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="progress" name="progress">
  Was the User/Requestor kept informed about the progress of the ticket?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="3_strike_R" name="3_strike_R" style="color:red">
      Did the engineer follow the 3 strike policy, if user was not responsive? :
      </label>
     </div>	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="progress" value="exc">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="progress" value="good">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="progress" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="strike_3_R" value="exc">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="strike_3_R" value="good">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="strike_3_R" value="na">
     <label for="male">NA</label> <br><br>
	 
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_4" name="overall_4" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_4"name="feedback_4" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
 
    <div class="col-md-12"><br>
     <div class="form-group" align="center">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
       <!-- <button class="btn btn-info btn-sm"  onclick="myfunction()">
        send 
       </button> -->
      </div>
     </div>
	 </div>
	 
</form>
</div>


<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
	$(document).ready(function(){
		var date_input=$('input[name="inc_date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>



</body>

<html>