<?php
    include("dbconn.php");
    $sql = "select MID from add_employee where EMP_NAME='".$_GET['name']."' ;";
    
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo $row['MID'];
    }else{
        echo "not found";
    }
    //echo "hello";
?>