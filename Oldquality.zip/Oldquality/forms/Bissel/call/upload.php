<?php
// start a session
session_start();
 
// manipulate session variables
?>


<?php
 

if(isset($_POST['submit'])){
    include('dbconn.php');
  
    // $emp_id=$_POST['emp_id'];
    // echo $emp_id;
    // $vip_user=$_POST['vip_user'];
    $PID=10;
    $auditor_mid=  $_SESSION['user_mid'];
    $eng_name=mysqli_real_escape_string($conn,$_POST['eng_name']);
    $ticket_no=mysqli_real_escape_string($conn,$_POST['ticket_no']);
    $vip_user=mysqli_real_escape_string($conn,$_POST['vip_user']);
    $emp_id=mysqli_real_escape_string($conn,$_POST['emp_id']);
    $date=mysqli_real_escape_string($conn,$_POST['date']);
    $Audit_by=mysqli_real_escape_string($conn,$_POST['Audit_by']);
    $call_no=mysqli_real_escape_string($conn,$_POST['call_no']);
    $type_of_audit=mysqli_real_escape_string($conn,$_POST['type_of_audit']);
    $type_call=mysqli_real_escape_string($conn,$_POST['type_call']);
    $overall_score=mysqli_real_escape_string($conn,$_POST['overall_score']);
    $level=mysqli_real_escape_string($conn,$_POST['level']);
    $pro=mysqli_real_escape_string($conn,$_POST['pro']);
    $speech=mysqli_real_escape_string($conn,$_POST['speech']);
    $rate=mysqli_real_escape_string($conn,$_POST['rate']);
    $flu=mysqli_real_escape_string($conn,$_POST['flu']);
    $tone=mysqli_real_escape_string($conn,$_POST['tone']);
    $gram=mysqli_real_escape_string($conn,$_POST['gram']);
    $overall_1=mysqli_real_escape_string($conn,$_POST['overall_1']);
    $feedback_1=mysqli_real_escape_string($conn,$_POST['feedback_1']);
    $court_Pro=mysqli_real_escape_string($conn,$_POST['court_Pro']);
    $emp_own=mysqli_real_escape_string($conn,$_POST['emp_own']);
    $guide_ins=mysqli_real_escape_string($conn,$_POST['guide_ins']);
    $overall_2=mysqli_real_escape_string($conn,$_POST['overall_2']);
    $feedback_2=mysqli_real_escape_string($conn,$_POST['feedback_2']);
    $approp=mysqli_real_escape_string($conn,$_POST['approp']);
    $ho_mu=mysqli_real_escape_string($conn,$_POST['ho_mu']);
    $call_pers=mysqli_real_escape_string($conn,$_POST['call_pers']);
    $automation_R=mysqli_real_escape_string($conn,$_POST['automation_R']);
    $ticket_no_call=mysqli_real_escape_string($conn,$_POST['ticket_no_call']);
    $call_closed=mysqli_real_escape_string($conn,$_POST['call_closed']);
    $overall_3=mysqli_real_escape_string($conn,$_POST['overall_3']);
    $feedback_3=mysqli_real_escape_string($conn,$_POST['feedback_3']);
    $listen_sk=mysqli_real_escape_string($conn,$_POST['listen_sk']);
    $comp_sk=mysqli_real_escape_string($conn,$_POST['comp_sk']);
    $pro_sk=mysqli_real_escape_string($conn,$_POST['pro_sk']);
    $overall_4=mysqli_real_escape_string($conn,$_POST['overall_4']);
    $feedback_4=mysqli_real_escape_string($conn,$_POST['feedback_4']);
    $use_pro=mysqli_real_escape_string($conn,$_POST['use_pro']);
    $reg_lan=mysqli_real_escape_string($conn,$_POST['reg_lan']);
    $create_ticket=mysqli_real_escape_string($conn,$_POST['create_ticket']);
    $eng_rude=mysqli_real_escape_string($conn,$_POST['eng_rude']);
    $release_call=mysqli_real_escape_string($conn,$_POST['release_call']);
    $overall_5=mysqli_real_escape_string($conn,$_POST['overall_5']);
    $feedback_5=mysqli_real_escape_string($conn,$_POST['feedback_5']);

   
    
    

  
   
    $qry= "INSERT INTO `bissell_call`( `eng_name`, `ticket_no`, `vip_user`, `emp_id`, `date`, `Audit_by`, `call_no`, `type_of_audit`, `type_call`, `overall_score`, `level`, `pro`, `speech`, `rate`, `flu`, `tone`, `gram`, `overall_1`, `feedback_1`, `court_Pro`, `emp_own`, `guide_ins`, `overall_2`, `feedback_2`, `approp`, `ho_mu`, `call_pers`, `automation_R`, `ticket_no_call`, `call_closed`, `overall_3`, `feedback_3`, `listen_sk`, `comp_sk`, `pro_sk`, `overall_4`, `feedback_4`, `use_pro`, `reg_lan`, `create_ticket`, `eng_rude`, `release_call`, `overall_5`, `feedback_5`, `auditor_mid`,`PID`) VALUES ('$eng_name','$ticket_no','$vip_user','$emp_id','$date','$Audit_by','$call_no','$type_of_audit','$type_call','$overall_score','$level','$pro','$speech','$rate','$flu','$tone','$gram','$overall_1','$feedback_1','$court_Pro','$emp_own','$guide_ins','$overall_2','$feedback_2','$approp','$ho_mu','$call_pers','$automation_R','$ticket_no_call','$call_closed','$overall_3','$feedback_3','$listen_sk','$comp_sk','$pro_sk','$overall_4','$feedback_4','$use_pro','$reg_lan','$create_ticket','$eng_rude','$release_call','$overall_5','$feedback_5','$auditor_mid','$PID')";
    
    $run= mysqli_query($conn,$qry);
    
    if($run==true)
    {
        ?>
        <script>
                alert('Data Inserted Succesfully');
                window.open('BISSELL.php','_self');

        </script>

<?php

    }
}



?>
