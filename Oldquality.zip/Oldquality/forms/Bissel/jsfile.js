
function speech_op(){ 
        var pro = document.getElementsByName('pro');
        var speech = document.getElementsByName('speech');
        var rate = document.getElementsByName('rate');
        var flu = document.getElementsByName('flu');
        var tone = document.getElementsByName('tone');
        var gram = document.getElementsByName('gram');
        var op=0;
        for(i = 0; i < pro.length; i++){
            if(pro[i].checked){
                if(pro[i].value==101){
                    op+=10;
                    break;
                }
                else{

                    op+=parseInt(pro[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < speech.length; i++){
            if(speech[i].checked){
                op+=parseInt(speech[i].value);
                break;
            } 
        }
        for(i = 0; i < rate.length; i++){
            if(rate[i].checked){
                op+=parseInt(rate[i].value);
                break;
            } 
        }
        for(i = 0; i < flu.length; i++){
            if(flu[i].checked){
                op+=parseInt(flu[i].value);
                break;
            } 
        }
        for(i = 0; i < tone.length; i++){
            if(tone[i].checked){
                op+=parseInt(tone[i].value);
                break;
            } 
        }
        for(i = 0; i < gram.length; i++){
            if(gram[i].checked){
                op+=parseInt(gram[i].value);
                break;
            } 
        }
        audit_form.feedback1.value =parseFloat((op/60)*100).toFixed(2);
        overall_sc();
    }

    function courtesy_op(){
        var courtesy = document.getElementsByName('courtesy');
        var empathy = document.getElementsByName('empathy');
        var guide = document.getElementsByName('guide');
        var op=0;
        for(i = 0; i < courtesy.length; i++){
            if(courtesy[i].checked){
                op+=parseInt(courtesy[i].value);
                break;
            } 
        }
        for(i = 0; i < empathy.length; i++){
            if(empathy[i].checked){
                op+=parseInt(empathy[i].value);
                break;
            } 
        }
        for(i = 0; i < guide.length; i++){
            if(guide[i].checked){
                op+=parseInt(guide[i].value);
                break;
            } 
        }
        audit_form.feedback2.value =parseFloat((op/30)*100).toFixed(2);
        overall_sc();
    }

    function overall_sc(){   
        if(audit_form.remote_ctrl.value === 'no'){         

         a=   audit_form.overall_score.value = "0";
         console.log(a);

        }
        else{
            v1 = parseInt(audit_form.feedback1.value);
            v2 = parseInt(audit_form.feedback2.value);
          val=  audit_form.overall_score.value =(v1 + v2)/2;
          console.log(val);
          if(val==100){
            document.getElementById('alert').innerHTML="BLUE ALERT";
            document.getElementById('alert').style.backgroundColor =  
                                "blue"; 
            

          }
          else if(val>=90 && val<100 ){
            document.getElementById('alert').innerHTML="GREEN ALERT";
            document.getElementById('alert').style.backgroundColor =  
                                "green"; 
            

          }
          else if(val>=80 && val<90 ){
            document.getElementById('alert').innerHTML="AMBER ALERT";
            document.getElementById('alert').style.backgroundColor =  
                                "#ffbf00"; 
            

          }
          else if(val<80 && val>0 ){
            document.getElementById('alert').innerHTML="RED ALERT";
            document.getElementById('alert').style.backgroundColor =  
                                "red"; 
            

          }



          else if(val==0){
            document.getElementById('alert').innerHTML="FATAL ALERT";
            document.getElementById('alert').style.backgroundColor =  
                                "red"; 

          }
          

        }   
    }
    

    function get_emp_id(){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                audit_form.emp_id.value = this.responseText;
            }
            
        };
        xmlhttp.open("GET", "getempid.php?name=" + audit_form.eng_name.value, true);
        xmlhttp.send();
    }

  
