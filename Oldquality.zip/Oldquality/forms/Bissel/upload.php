<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php

    
    function gradeCalc($val){
        if($val ==='10') return 'Excellent';
        else if($val === '7') return 'Good';
        else if($val === '5') return 'Needs Improvement';
        else return 'NA';
    }
    if(isset($_POST['submit'])){
        //echo gradeCalc($_POST['feedback1']);
      $a =gradeCalc($_POST['pro']);
      echo $a;

        // if($_POST['remote_ctrl'] === 'no') echo "0 Score";
        
        $sql = "insert into('feedback1','feedback2')('".$_POST['feedback1']."')";
       


    }
?>