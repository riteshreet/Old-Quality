





    function procc_meth(){
        var eng_cont = document.getElementsByName('eng_cont');
        var tic_link = document.getElementsByName('tic_link');
        var cor_case = document.getElementsByName('cor_case');
        var cor_cat = document.getElementsByName('cor_cat');
        var cor_pri = document.getElementsByName('cor_pri');
        var cor_inc = document.getElementsByName('cor_inc');
        var hold_reason = document.getElementsByName('hold_reason');
        var rem_script = document.getElementsByName('rem_script');
        var escalate = document.getElementsByName('escalate');
        
        

        var op=0;
        var temp=1;
     
       
        for(i = 0; i < eng_cont.length; i++){
            if(eng_cont[i].checked){
                if(eng_cont[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(eng_cont[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < tic_link.length; i++){
            if(tic_link[i].checked){
                if(tic_link[i].value==101){
                    op+=10;
                }
                
                
                else{
                    op+=parseInt(tic_link[i].value);
                   
                }
               
            } 
       }
    
           
        for(i = 0; i < cor_case.length; i++){
      
            if(cor_case[i].checked){
                
                if(cor_case[i].value==101){
                    op+=10;
                }
                else if(cor_case[i].value==0){
                    temp=0;
                    break;
                }
                
                
                
                else{
                    op+=parseInt(cor_case[i].value);
                  
                }
               
                   } 
         
     
                }
               
        for(i = 0; i < cor_cat.length; i++){
            if(cor_cat[i].checked){
                if(cor_cat[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(cor_cat[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < cor_pri.length; i++){
            if(cor_pri[i].checked){
                if(cor_pri[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(cor_pri[i].value);
                    break;
                }
               
            } 
        }
       
        for(i = 0; i < cor_inc.length; i++){
            if(cor_inc[i].checked){
                if(cor_inc[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(cor_inc[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < hold_reason.length; i++){
            if(hold_reason[i].checked){
                if(hold_reason[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(hold_reason[i].value);
                    break;
                }
               
            } 
        }

       
        for(i = 0; i < rem_script.length; i++){
            if(rem_script[i].checked){
            
               
                if(rem_script[i].value==101){
                    op+=10;
                }
                else if(rem_script[i].value==0){
                    temp=0;
                    break;
                }
                
                  
                else{
                    op+=parseInt(rem_script[i].value);
                   
                }
               
                  }
           
    
         

        }
    
       
        for(i = 0; i < escalate.length; i++){
            if(escalate[i].checked){
                if(escalate[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(escalate[i].value);
                    break;
                }
               
            } 
        }


        console.log(temp);
       if(temp==0){
           audit_form.Audit_score0.value=0.0;
       }else{
        audit_form.Audit_score0.value =parseFloat((op/90)*100).toFixed(2);
        
       }

       overall_sc();
        
      
    }



    function docu_p(){
        var appropriately=document.getElementsByName('appropriately');
        var exact_issue=document.getElementsByName('exact_issue');
        var vital_information=document.getElementsByName('vital_information');
        var troubleshooting=document.getElementsByName('troubleshooting');
        var cor_temp=document.getElementsByName('cor_temp');
        var followed_up=document.getElementsByName('followed_up');
        var summary=document.getElementsByName('summary');
        var right_resolve=document.getElementsByName('right_resolve');
        var knowledge_base=document.getElementsByName('knowledge_base');
        var op=0;
        for(i = 0; i < appropriately.length; i++){
            if(appropriately[i].checked){
                if(appropriately[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(appropriately[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < exact_issue.length; i++){
            if(exact_issue[i].checked){
                if(exact_issue[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(exact_issue[i].value);
                    break;
                }
               
            } 
        }
        for(i = 0; i < vital_information.length; i++){
            if(vital_information[i].checked){
                if(vital_information[i].value==101){
                    op+=10;
                }else{
                    op+=parseInt(vital_information[i].value);
                    break;
                }
               
            } 
        }


    }
   
   
   
   
   

    function overall_sc(){   
        v1 = parseFloat(audit_form.Audit_score0.value);
        // console.log(v5);
       
       
        if(v1==0){
           

          val1=  audit_form.audit_score.value=0.0;
            check_color(val1);
            
        }
       
        else{
            v1 = parseFloat(audit_form.Audit_score0.value);
           
          val2=  audit_form.audit_score.value =parseFloat((v1 )/1).toFixed(2);
          check_color(val2);

        }
    
     
     
      
           

    }

        
          function check_color(val){
          if(val==100){
            document.getElementById('alert').innerHTML="BLUE ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "blue"; 
                              a=  audit_form.level_1.value="A+";
                            
                        

            

          }
          else if(val>=90 && val<100 ){
            document.getElementById('alert').innerHTML="GREEN ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "green"; 
                                audit_form.level_1.value="A";
            

          }
          else if(val>=80 && val<90 ){
            document.getElementById('alert').innerHTML="AMBER ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "#ffbf00"; 
                                audit_form.level_1.value="B";
            

          }
          else if(val<80 && val>0 ){
            document.getElementById('alert').innerHTML="RED ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "red"; 
                                audit_form.level_1.value="C";
            

          }



          else if(val==0){
            document.getElementById('alert').innerHTML="FATAL ALERT";
            document.getElementById('div_alert').style.backgroundColor =  
                                "red"; 
                                audit_form.level_1.value="C";

          }
          

        }   
    
    

    function get_emp_id(){
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                audit_form.emp_id.value = this.responseText;
            }
            
        };
        xmlhttp.open("GET", "getempid.php?name=" + audit_form.eng_name.value, true);
        xmlhttp.send();
    }

  
