<?php
// start a session
session_start();
 
// manipulate session variables
?>


<?php
 

if(isset($_POST['submit'])){
    include('dbconn.php');
  
    // $emp_id=$_POST['emp_id'];
    // echo $emp_id;
    // $vip_user=$_POST['vip_user'];
    $PID=20;
    $auditor_mid=  $_SESSION['user_mid'];
    $eng_name=mysqli_real_escape_string($conn,$_POST['eng_name']); 
    $ticket_no=mysqli_real_escape_string($conn,$_POST['ticket_no']); 
    $Resolver_Group=mysqli_real_escape_string($conn,$_POST['Resolver_Group']); 
    $emp_id=mysqli_real_escape_string($conn,$_POST['emp_id']); 
    $date=mysqli_real_escape_string($conn,$_POST['date']); 
    $date_log=mysqli_real_escape_string($conn,$_POST['date_log']); 
    $Ticket_Status=mysqli_real_escape_string($conn,$_POST['Ticket_Status']); 
    $inc_pri=mysqli_real_escape_string($conn,$_POST['inc_pri']); 
    $Audited_by=mysqli_real_escape_string($conn,$_POST['Audited_by']); 
    $audit_score=mysqli_real_escape_string($conn,$_POST['audit_score']); 
    $level=mysqli_real_escape_string($conn,$_POST['level']); 
    $eng_cont=mysqli_real_escape_string($conn,$_POST['eng_cont']); 
    $tic_link=mysqli_real_escape_string($conn,$_POST['tic_link']); 
    $cor_case=mysqli_real_escape_string($conn,$_POST['cor_case']); 
    $cor_cat=mysqli_real_escape_string($conn,$_POST['cor_cat']); 
    $cor_pri=mysqli_real_escape_string($conn,$_POST['cor_pri']); 
    $cor_inc=mysqli_real_escape_string($conn,$_POST['cor_inc']); 
    $hold_reason=mysqli_real_escape_string($conn,$_POST['hold_reason']); 
    $rem_script=mysqli_real_escape_string($conn,$_POST['rem_script']); 
    $escalate=mysqli_real_escape_string($conn,$_POST['escalate']); 
    $Audit_score0=mysqli_real_escape_string($conn,$_POST['Audit_score0']); 
    $feedback_1=mysqli_real_escape_string($conn,$_POST['feedback_1']); 
    $appropriately=mysqli_real_escape_string($conn,$_POST['appropriately']); 
    $exact_issue=mysqli_real_escape_string($conn,$_POST['exact_issue']); 
    $vital_information=mysqli_real_escape_string($conn,$_POST['vital_information']); 
    $troubleshooting=mysqli_real_escape_string($conn,$_POST['troubleshooting']); 
    $cor_temp=mysqli_real_escape_string($conn,$_POST['cor_temp']); 
    $followed_up=mysqli_real_escape_string($conn,$_POST['followed_up']); 
    $summary=mysqli_real_escape_string($conn,$_POST['summary']); 
    $right_resolve=mysqli_real_escape_string($conn,$_POST['right_resolve']); 
    $knowledge_base=mysqli_real_escape_string($conn,$_POST['knowledge_base']); 
    $Audit_score1=mysqli_real_escape_string($conn,$_POST['Audit_score1']); 
    $feedback_2=mysqli_real_escape_string($conn,$_POST['feedback_2']); 
    $res_issue=mysqli_real_escape_string($conn,$_POST['res_issue']); 
    $res_provided=mysqli_real_escape_string($conn,$_POST['res_provided']); 
    $self_aut=mysqli_real_escape_string($conn,$_POST['self_aut']); 
    $user_confim=mysqli_real_escape_string($conn,$_POST['user_confim']); 
    $overall_3=mysqli_real_escape_string($conn,$_POST['overall_3']); 
    $feedback_3=mysqli_real_escape_string($conn,$_POST['feedback_3']); 
    $req_inform=mysqli_real_escape_string($conn,$_POST['req_inform']); 
    $strike_3=mysqli_real_escape_string($conn,$_POST['strike_3']); 
    
    $overall_4=mysqli_real_escape_string($conn,$_POST['overall_4']); 
    $feedback_4=mysqli_real_escape_string($conn,$_POST['feedback_4']); 
    
   

  
   
    $qry= "INSERT INTO `bissell_process`( `eng_name`, `ticket_no`, `Resolver_Group`, `emp_id`, `date`, `date_log`, `Ticket_Status`, `inc_pri`, `Audited_by`, `audit_score`, `level`, `eng_cont`, `tic_link`, `cor_case`, `cor_cat`, `cor_pri`, `cor_inc`, `hold_reason`, `rem_script`, `escalate`, `Audit_score0`, `feedback_1`, `appropriately`, `exact_issue`, `vital_information`, `troubleshooting`, `cor_temp`, `followed_up`, `summary`, `right_resolve`, `knowledge_base`, `Audit_score1`, `feedback_2`, `res_issue`, `res_provided`, `self_aut`, `user_confim`, `overall_3`, `feedback_3`, `req_inform`, `strike_3`, `overall_4`, `feedback_4`, `auditor_mid`, `PID`) VALUES ('$eng_name','$ticket_no','$Resolver_Group','$emp_id','$date','$date_log','$Ticket_Status','$inc_pri','$Audited_by','$audit_score','$level','$eng_cont','$tic_link','$cor_case','$cor_cat','$cor_pri','$cor_inc','$hold_reason','$rem_script','$escalate','$Audit_score0','$feedback_1','$appropriately','$exact_issue','$vital_information','$troubleshooting','$cor_temp','$followed_up','$summary', '$right_resolve', '$knowledge_base', '$Audit_score1', '$feedback_2', '$res_issue', '$res_prodedvi', '$self_aut', '$user_confim', '$overall_3', '$feedback_3', '$req_inform', '$strike_3', '$overall_4', '$feedback_4', '$auditor_mid', '$PID')";
    
    $run= mysqli_query($conn,$qry);
    
    if($run==true)
    {
        ?>
        <script>
                alert('Data Inserted Succesfully');
                window.open('BISSELL_P.php','_self');

        </script>

<?php

    }
}



?>
