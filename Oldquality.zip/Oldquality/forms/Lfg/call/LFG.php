
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>LFG CALL AUDIT</title>    


  
<script type="text/javascript" src="jsfile.js"></script>
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso12.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; color: #000000}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: #ffffff !important;} .asteriskField{color: red;}


</style>
<body onload="speech_op();courtesy_op();overall_sc();get_emp_id();">
<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(187,221,189,0.549);"> 
  <form method="post" action="upload.php" name="audit_form">
   <div class="row" style="border-style:solid;border-width:2px;height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold"> LFG Call Audit </h4>
      </label>
     </div>	
	 </div>
	 </div>
	 <div class="row" style="border-style:solid;border-width:2px; height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold" id="alert" style="background-color: green;">BLUE ALERTS </h4>
      </label>
     </div>	
	 </div>
	 </div>   
	<div class="row" style="border-style:solid;border-width:2px">
	<div class="col-md-3 " >
     <div class="form-group"  >
	 
      <label class="control-label requiredField" for="eng_name" name="eng_name">
       Engineer Name :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="eng_name" name="eng_name" onchange="get_emp_id()" >
        <?php
            foreach($map as $name => $roll )
                echo "<option>".$name."</option>";
        ?>
      </select>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="ticket_no">
       Ticket Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="ticket_no" name="ticket_no" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="vip_user">
       Is a VIP User :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="vip_user" name="vip_user">
       <option value="Yes">
        Yes
       </option>
       <option value="No">
        No
       </option>
      </select>
     </div>
    </div>
    <!-- =====================================================Section 1============================================================== -->
  
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="emp_id">
       Employee ID :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="emp_id" name="emp_id" type="text"/>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="date">
       Audit Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
	  <div class="form-group ">
      <label class="control-label requiredField" for="type_of_call">
       Type of Call :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="type_of_call" name="type_of_call">
       <option value="recorded_call">
        Inbound call
       </option>
       <option value="live_call">
        Outbound Call
       </option>
	   </option>
      </select>
     </div> 
    </div>
	
	<!-- =====================================================Section 2============================================================== -->
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="call_no">
       Call Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="call_no" name="call_no" type="text"/>
     </div>
	 <div class="form-group ">
      <label class="control-label requiredField" for="type_of_audit">
       Type of Audit :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="type_of_audit" name="type_of_audit">
       <option value="recorded call">
        Recorded call
       </option>
       <option value="live call">
        Live Call
       </option>
	   </option>
       <option value="tickets">
        Tickets
       </option>
      </select>
     </div>       
    </div>

   <!-- =====================================================Section 3============================================================== -->
   <div class="col-md-3 " >
  
      <div class="form-group">
      <label class="control-label requiredField" for="overall_score">
       Overall Score :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="overall_score" name="overall_score" type="text" >
     </div>
	 
      <div class="form-group ">
      <label class="control-label requiredField" for="level">
       Level :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="level" name="level" type="text" >
     </div>
    </div>
   </div>
    <!-- =====================================================Section 4============================================================== -->
	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Speech </h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="pronunciation" name="pronunciation">
       Pronunciation :
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp_Clarity" name="sp_Clarity">
       Speech Clarity :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="rate" name="rate">
       Rate of Speech :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="flu" name="flu">
       Fluency :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="tone" name="tone">
       Tone :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="gram" name="gram">
       Grammar :
      </label>
     </div>	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="pronunciation" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="pronunciation" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="pronunciation" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="pronunciation" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="sp_Clarity" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="sp_Clarity" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="sp_Clarity" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="sp_Clarity" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="rate" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="rate" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="rate" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="rate" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="flu" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="flu" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="flu" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="flu" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="tone" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="tone" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="tone" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="tone" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="gram" value="10" onclick="speech_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="gram" value="5" onclick="speech_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="gram" value="0" onclick="speech_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="gram" value="10" checked onclick="speech_op()">
     <label for="male">NA</label>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_1" name="overall_1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
          <textarea id="feedback_1"name="feedback_1" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
 
 <!-- =====================================================Section 4============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Courtesy and Empathy </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="courtesy" name="courtesy" style="color:red">
       Courtesy and Professionalism :
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="empathy" name="empathy">
       Empathy and Ownership :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="guide" name="guide">
       Guiding And Instructing the customer :
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="courtesy" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="courtesy" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="courtesy" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="courtesy" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="empathy" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="empathy" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="empathy" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="empathy" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="guide" value="10" onclick="courtesy_op()">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="guide" value="5" onclick="courtesy_op()">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="guide" value="0" onclick="courtesy_op()">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="guide" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_2" name="overall_2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <<textarea id="feedback_2"name="feedback_2" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
   <!-- =====================================================Section 5============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Call Etiquette </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="greeting" name="greeting">
      Did the engineer use the proper greeting by identifying him/herself?
      </label>
	 </div>	 
	  <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="lan_id" name="lan_id">
      Did the engineer request for the user's LAN id?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="call_pers" name="call_pers">
      Was the call personalized?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="cont_no" name="cont_no">
      Did the engineer confirm the user's contact information and location?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="hold" name="hold">
      Did the engineer use the proper hold/transfer etiquette?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="remote_ctrl" name="remote_ctrl" style="color:red">
      Did the engineer use the proper Screen Remote Control etiquette?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="tickets_no" name="tickets_no">
      Did the engineer attempt to provide the ticket number on the call?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="resol" name="resol">
      Did the engineer confirm the resolution on the call?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="add_help" name="add_help">
      Did the engineer offer additional help before ending the call?
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="call_closed" name="call_closed">
      Was the call closed appropriately?
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <br>
	 <input type="radio" id="yes" name="greeting" value="10"  onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="greeting" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="greeting" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="lan_id" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="lan_id" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="lan_id" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="call_pers" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_pers" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_pers" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="cont_no" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="cont_no" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="cont_no" value="10"  onclick="call_eqt()">
     <label for="male">NA</label> <br><br><br>	
	 
	 <input type="radio" id="yes" name="hold" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="hold" value="0"  onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="hold" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="remote_ctrl" value="yes" onclick="overall_sc();">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="remote_ctrl" value="no" onclick="overall_sc();">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="remote_ctrl" value="na" onclick="overall_sc();">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="tickets_no" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="tickets_no" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="tickets_no" value="na">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="yes" name="resol" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="resol" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="resol" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="add_help" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="add_help" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="add_help" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="call_closed" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_closed" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_closed" value="na">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_3" name="overall_3" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <<textarea id="feedback_3"name="feedback_3" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 6============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Listening,Paraphrasing and Probing </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="Listen_skill" name="Listen_skill">
       Listening Skills?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="emp_own" name="emp_own">
       Comprehension and Paraphrasing :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="issue_1" name="issue_1">
       Did the engineer Understand the issue?
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="probing" name="probing">
       Probing?
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="exc" name="Listen_skill" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="Listen_skill" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="Listen_skill" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="Listen_skill" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="emp_own" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="emp_own" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="emp_own" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="emp_own" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="issue_1" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="issue_1" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="issue_1" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="issue_1" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="probing" value="exc">
     <label for="male">Excellent</label>
	 <input type="radio" id="good" name="probing" value="good">
     <label for="male">Good</label> 
	 <input type="radio" id="need_imp" name="probing" value="need_imp">
     <label for="male">Needs Improvement</label>
	 <input type="radio" id="na" name="probing" value="na">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_4" name="overall_4" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
    <<textarea id="feedback_4"name="feedback_4" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 7============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Inappropriate Behaviour</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="use_pro" name="use_pro">
       Did the engineer use Profanity on the call?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="reg_lang" name="reg_lang">
       Did the engineer use any regional language?
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="create_ticket" name="create_ticket">
       Did the engineer create a ticket for this conversation?
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="eng_rude" name="eng_rude">
       Was the engineer rude on the call?
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="call_perm" name="call_perm">
       Did the engineer release the call without the user's permission?
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <input type="radio" id="yes" name="use_pro" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="use_pro" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="use_pro" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="reg_lang" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="reg_lang" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="reg_lang" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="create_ticket" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="create_ticket" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="create_ticket" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="eng_rude" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="eng_rude" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="eng_rude" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="call_perm" value="yes">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="call_perm" value="no">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="call_perm" value="na">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_5" name="overall_5" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <<textarea id="feedback_5"name="feedback_5" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div><br>
 
    <div class="col-md-12">
     <div class="form-group" align="center">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
       <!-- <button class="btn btn-info btn-sm"  onclick="myfunction()">
        send 
       </button> -->
      </div>
     </div>
	 </div>
	 
</form>
</div>


<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>



</body>

<html>