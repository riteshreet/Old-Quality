
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>LFG CALL AUDIT</title>    


  
<script type="text/javascript" src="jsfile.js"></script>
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso12.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; color: #000000}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: #ffffff !important;} .asteriskField{color: red;}


</style>
<body onload="speech_op();courtesy_op();overall_sc();get_emp_id();">
<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(187,221,189,0.549);"> 
  <form method="post" action="upload.php" name="audit_form">
   <div class="row" style="border-style:solid;border-width:2px;height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold"> LFG Process Audit </h4>
      </label>
     </div>	
	 </div>
	 </div>
	 <div class="row" style="border-style:solid;border-width:2px; height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold" id="alert" style="background-color: green;">BLUE ALERT </h4>
      </label>
     </div>	
	 </div>
	 </div>   
	<div class="row" style="border-style:solid;border-width:2px">
	<div class="col-md-3 " >
     <div class="form-group"  >
	 
      <label class="control-label requiredField" for="eng_name" name="eng_name">
       Engineer Name :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="eng_name" name="eng_name" onchange="get_emp_id()" >
        <?php
            foreach($map as $name => $roll )
                echo "<option>".$name."</option>";
        ?>
      </select>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="inc_no">
       Incident Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="inc_no" name="inc_no" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="inc_status">
       Incident Status :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="inc_status" name="inc_status">
       <option value="Active">
        Active
       </option>
       <option value="Pending user">
       Pending user
       </option>
	    <option value="Pending 3rd party">
        Pending 3rd party
       </option>
	   <option value="Resolved">
        Resolved
       </option>
	   <option value="Closed">
        Closed
       </option>
      </select>
     </div>
    </div>
    <!-- =====================================================Section 1============================================================== -->
  
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="emp_id">
       Employee ID :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="emp_id" name="emp_id" type="text"/>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="date">
       Audit Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
	  <div class="form-group ">
      <label class="control-label requiredField" for="inc_priority">
       Incident Priority :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="inc_priority" name="inc_priority">
       <option value="Critical">
        Critical
       </option>
       <option value="High">
       High
       </option>
	    <option value="Moderate">
        Moderate
       </option>
      </select>
     </div>
    </div>
	
	<!-- =====================================================Section 2============================================================== -->
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="Resolver_group">
       Resolver Group :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Resolver_group" name="Resolver_group" type="text"/>
     </div>
   <div class="form-group ">
      <label class="control-label requiredField" for="inc_date">
       Incident logged Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="inc_date" name="inc_date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>   
 <div class="form-group ">
      <label class="control-label requiredField" for="Audit_by">
       Audited by :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Audit_by" name="Audit_by" type="text"/>
     </div>	 
    </div>

   <!-- =====================================================Section 3============================================================== -->
   <div class="col-md-3 " >
  
      <div class="form-group">
      <label class="control-label requiredField" for="Audit_score">
       Audit Score :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Audit_score" name="Audit_score" type="text" >
     </div>
	 
      <div class="form-group ">
      <label class="control-label requiredField" for="level">
       Level :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="level" name="level" type="text" >
     </div>
    </div>
   </div>
    <!-- =====================================================Section 4============================================================== -->
	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Process methodology</h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="contact" name="contact">
       Did the engineer contact the user within 1hr from ticket assigment?  :
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="verification" name="verification" style="color:red">
       Did the engineer follow the verification process? :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="ticket_link" name="ticket_link">
       Were the relavent tickets linked? (Service Board) :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="ci_symp" name="ci_symp">
       "Did the Engineer choose the correct CI and symptom? (If CI is not listed, please use their PC name as the CI and document the app in the Short Description section.)::
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="priority" name="priority">
       Did the Engineer choose the correct Priority? (Impact / Urgency, if priority is auto-populated):
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_inc" name="cor_inc">
       Did the Engineer choose the correct incident state(Active/Waiting  for user's response/Pending with third party vendor/Resolved) :
      </label>
     </div>	
     <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="script" name="script" style="color:red">
      Was the remote script followed ? :
      </label>
     </div>	
      <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="escalate" name="escalate">
      Did the Engineer Route/escalate the ticket to the correct resolver group, if required?:
      </label>
     </div>		 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="contact" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="contact" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="contact" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="verification" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="verification" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="verification" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="ticket_link" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="ticket_link" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="ticket_link" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="ci_symp" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="ci_symp" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="ci_symp" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br><br>
	  
	 <input type="radio" id="exc" name="priority" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="priority" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="priority" value="10" checked onclick="speech_op()">
     <label for="male">NA</label> <br><br><br><br>
	  
	 <input type="radio" id="exc" name="cor_inc" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="cor_inc" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="cor_inc" value="10" checked onclick="speech_op()">
     <label for="male">NA</label><br><br>
	 
	  <input type="radio" id="exc" name="script" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="script" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="script" value="10" checked onclick="speech_op()">
     <label for="male">NA</label><br><br><br>
	 
	  <input type="radio" id="exc" name="escalate" value="10" onclick="speech_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="escalate" value="5" onclick="speech_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="escalate" value="10" checked onclick="speech_op()">
     <label for="male">NA</label><br>
	 
	 
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_1" name="overall_1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
      <textarea id="feedback_1"name="feedback_1" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
 
 <!-- =====================================================Section 4============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Documentation</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="description" name="description">
       Did the engineer update the short description appropriately? :
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="vital_information" name="vital_information" style="color:red">
       Did the engineer capture all the vital information? (Host Name, Contact details, Screen shot) :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="troubleshooting" name="troubleshooting" style="color:red">
       Did the engineer capture detailed documentation of troubleshooting steps? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="template" name="template">
       Did the engineer use the correct templates? (Email; Triage/Escalation):
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="followed_up" name="followed_up">
      Was the ticket followed-up and documented  in a timely manner? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="summary" name="summary">
      Did the engineer update relevant summary of the resolution under resolution notes?  :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="resolution" name="resolution">
     Did the engineer select the right resolution code while resolving the ticket?   :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="knowledge_base" name="knowledge_base" style="color:red">
     Did the engineer update the reference of Knowledge Base/SOP in the ticket?  :
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="description" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="description" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="description" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="vital_information" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="vital_information" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="vital_information" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="troubleshooting" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="troubleshooting" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="troubleshooting" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="template" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="template" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="template" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="followed_up" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="followed_up" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="followed_up" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="exc" name="summary" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="summary" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="summary" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="resolution" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="resolution" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="resolution" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	  <input type="radio" id="exc" name="knowledge_base" value="10" onclick="courtesy_op()">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="knowledge_base" value="5" onclick="courtesy_op()">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="knowledge_base" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_2" name="overall_2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
      <textarea id="feedback_2"name="feedback_2" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
   <!-- =====================================================Section 5============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Resolution and cloure </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="resolve_issue" name="resolve_isuue">
      Was the engineer able to resolve the issue?
      </label>
	 </div>	 
	  <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="resolution_provided" name="resolution_provided">
      Did the engineer explain the resolution provided to the user?
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="confirm_tic" name="confirm_tic">
      Did the engineer get confirmation from the user before resolving the ticket?
      </label>
	 </div>	 	 	    
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="sat_quot" name="sat_quot">
       <h4>Satisfaction Quotient </h4>
      </label>
     </div>
	 <br>
	 <input type="radio" id="yes" name="resolve_issue" value="10"  onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="resolve_issue" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="resolve_issue" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="resolution_provided" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="resolution_provided" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="resolution_provided" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="confirm_tic" value="10" onclick="call_eqt()">
     <label for="male">Yes</label>
	 <input type="radio" id="no" name="confirm_tic" value="0" onclick="call_eqt()">
     <label for="male">No</label> 
	 <input type="radio" id="na" name="confirm_tic" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	 <input type="text" id="overall_3" name="overall_3" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
<textarea id="feedback_3"name="feedback_3" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
  <!-- =====================================================Section 6============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Customer Expectation management </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="ticket_progress" name="ticket_progress">
       Was the User/Requestor kept informed about the progress of the ticket?
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="3_strike" name="3_strike">
       Did the engineer follow the 3 strike policy, if user was not responsive?:
      </label>
     </div>	 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="ticket_progress" value="exc">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="ticket_progress" value="good">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="ticket_progress" value="na">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="3_strike" value="exc">
     <label for="male">YES</label>
	 <input type="radio" id="good" name="3_strike" value="good">
     <label for="male">NO</label> 
	 <input type="radio" id="na" name="3_strike" value="na">
     <label for="male">NA</label> <br><br>
	 
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="overall_4" name="overall_4" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="feedback_4"name="feedback_4" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
 
    <div class="col-md-12"><br>
     <div class="form-group" align="center">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
       <!-- <button class="btn btn-info btn-sm"  onclick="myfunction()">
        send 
       </button> -->
      </div>
     </div>
	 </div>
	 
</form>
</div>


<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
	$(document).ready(function(){
		var date_input=$('input[name="inc_date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>



</body>

<html>