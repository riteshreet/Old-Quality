<?php
 include('dbconn.php');
 
 $MID=$_POST['MID'];
 
 
 $EMP_NAME=$_POST['EMP_NAME'];
 
 $projects_name=($_POST['Projects']);

 $sid=$_POST['sid'];



 $qry= "UPDATE `add_employee` SET `MID`='$MID',`EMP_NAME`='$EMP_NAME',`projects_name`='$projects_name' WHERE `MID`='$sid'";
 
 $run= mysqli_query($conn,$qry);
 if($run==true)
 {
     ?>
     <script>
             alert('Data Updated  Succesfully');
            window.open('update_form.php?sid=<?php echo $sid ?>','_self');
     </script>
     <?php

 }

 ?>