<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
include ('titlehead.php');
include ('dbconn.php');
$sid=$_GET['sid'];

$sql="SELECT * FROM `add_employee` WHERE `MID`='$sid'";
$run=mysqli_query($conn,$sql);
$data=mysqli_fetch_assoc($run);
?>

<form method="POST" action="updatedata.php">
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(127,121,189,0.249);border-style:solid;"> 
  <div class="col-md-12">
    <div class="form-group" align="center">
      <label class="control-label requiredField" for="name4" style="color:maroon">
       <h3><b><u>Edit Employee</u></b></h3>
    </div>
  </div>
  <div class="col-md-4">
</div>
<div class="col-md-4">
     <div class="form-group">
      <label class="control-label requiredField" for="name3">
       Employee ID (MID):
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="name3" name="MID" value="<?php echo $data['MID']; ?>" type="text">
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="name4">
       Employee Name:
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="name4" name="EMP_NAME" value="<?php echo $data['EMP_NAME']; ?>" type="text">
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="pro_name">
       Select the Project Name:
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="select2" name="Projects">
     
      <option value="">Select Project</option>
		<option <?php if($data['projects_name']=="Lincoln Financial Group"){echo "selected";}?>>Lincoln Financial Group</option>
		<option <?php if($data['projects_name']=="GameStop"){echo "selected";}?>>GameStop</option>
		<option <?php if($data['projects_name']=="Bissell"){echo "selected";}?>>Bissell</option>
		<option <?php if($data['projects_name']=="Dialog Semiconductor"){echo "selected";}?>>Dialog Semiconductor</option>
     
     
     
     
      <!-- <option value="Lincoln Financial Group">
        Lincoln Financial Group
       </option>
       <option value="GameStop">
        GameStop
       </option>
       <option value="Bissell">
        Bissell
       </option>
       <option value="Dialog Semiconductor">
        Dialog Semiconductor
       </option> -->
      </select>
     </div>	 
     <div class="form-group">
      <div>
      <input type="hidden" name="sid" value="<?php echo $sid;  ?>"/>
       <button class="btn btn-primary btn-lg" name="submit" type="submit" style="margin-left:70px;">
        Submit
       </button>
	  <a href="update_employee.php"><button class="btn btn-info btn-lg"  type="button"style="margin-left:20px;">
        Back
       </button></a> 
      </div>
	 </div>
	</div>
	</div>
  </div>
</div>




</form>
</body>
</html>
