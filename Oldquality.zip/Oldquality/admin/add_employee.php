<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
include ('titlehead.php');
?>

<form method="POST" action="add_employee.php">
<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(127,121,189,0.249);border-style:solid;"> 
  <div class="col-md-12">
    <div class="form-group" align="center">
      <label class="control-label requiredField" for="name4" style="color:maroon">
       <h3><b><u>Add New Employee</u></b></h3>
    </div>
  </div>
  <div class="col-md-4">
</div>
<div class="col-md-4">
     <div class="form-group" >
      <label class="control-label requiredField" for="name3">
       Employee ID (MID):
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="name3" name="MID" placeholder="E.g: M1065260" type="text" required>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="name4">
       Employee Name:
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="name4" name="EMP_NAME" type="text" required>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="pro_name">
       Select the Project Name:
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="select2" name="Projects" required>
      <option>Select a project</option>
       <option value="Lincoln Financial Group">
        Lincoln Financial Group
       </option>
       <option value="GameStop">
        GameStop
       </option>
       <option value="Bissell">
        Bissell
       </option>
       <option value="Dialog Semiconductor">
        Dialog Semiconductor
       </option>
      </select>
     </div>	 
     <div class="form-group">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
	  <input type=button class="btn btn-info btn-sm" onclick="window.location.href = 'admindash.php'" value="Back" />
        
      
      </div>
	 </div>
	</div>
	</div>
  </div>
</div>




</form>
</body>
</html>

<?php
if(isset($_POST['submit'])){
    include('dbconn.php');
    include ('check_user.php');
    $MID=$_POST['MID'];
    
    $EMP_NAME=$_POST['EMP_NAME'];
    $projects_name=($_POST['Projects']);

   $count= check($MID);
    if($count>0){
        ?>
        <script>
            alert('MID already exists');
            window.open('add_employee.php','_self');

        </script>

        <?php
    }else{

   
    $qry= "INSERT INTO `add_employee`(`MID`, `EMP_NAME`,`projects_name`) VALUES ('$MID','$EMP_NAME','$projects_name')";
    $run= mysqli_query($conn,$qry);
    if($run==true)
    {
        ?>
        <script>
                alert('Data Inserted Succesfully');

        </script>

<?php

    }
}
}


?>
