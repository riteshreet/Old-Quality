
<div class="admintitle" align="center">
<a href="logout.php" style="float: right;margin-right:30px;color:#fff; font:bolder">Logout</a>
<a href="admindash.php" style="float: left;margin-right:30px;color:#fff; font:bolder">Back To Dashboard</a>
<h1> Welcome to admin Dashboard</h1>

</div>