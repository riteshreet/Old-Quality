<?php
include('dbconn.php');

function check($MID){

    
    $chk_duplicate="SELECT `MID` FROM `add_employee` WHERE MID='$MID'";
    $duprow=mysqli_query($GLOBALS['conn'],$chk_duplicate);
    
    $count=mysqli_num_rows($duprow);
    return $count;
}


?>