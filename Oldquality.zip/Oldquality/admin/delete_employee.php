<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
include ('titlehead.php');
include ('dbconn.php');
$sid=$_POST['id'];


$sql="DELETE  FROM `add_employee` WHERE `MID`='$sid'";

$run=mysqli_query($conn,$sql);
if($run==true)
    {
        ?>
        <script>
                alert('Data Deleted Succesfully');
                window.open('update_employee.php','_self');

        </script>

<?php

    }


?>