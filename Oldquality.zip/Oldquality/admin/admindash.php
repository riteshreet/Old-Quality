<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
?>
    

<div class="admintitle" align="center">
<a href="logout.php" style="float: right;margin-right:30px;color:#fff; font:bolder">Logout</a>
<h1> Welcome to admin Dashboard</h1>

</div>

<div class="dashboard" >
    <table style="width:50%"align="center">
        <tr>
            <td> 1.</td><td><a href="add_employee.php">Insert Employee</a></td>

        </tr>
        <tr>
            <td> 2.</td><td><a href="update_employee.php">Update Employee</a></td>

        </tr>
     
        <tr>
            <td> 3.</td><td><a href="view.php">Manage Registered Employee</a></td>

        </tr>


    </table>


</div>

</body>


</head>



</html>