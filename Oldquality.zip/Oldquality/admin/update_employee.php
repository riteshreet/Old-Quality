<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
include ('titlehead.php');

?>
<table align="center">
<form action="update_employee.php" method="post">
    <br><tr>
        <th>Enter MID:</th>
        <td><input type="text" name="MID" style="margin-right:16px;" /> </td>
        <th>Enter Name:</th>
        <td><input type="text" name="name" style='margin-right:16px;' /> </td>
        <th>Choose project:</th>
        <td>
        <select class="select form-control" id="select2" name="Projects">
    <option>Select Project:</option>
        
       <option value="Lincoln Financial Group">
        Lincoln Financial Group
       </option>
       <option value="GameStop">
        GameStop
       </option>
       <option value="Bissell">
        Bissell
       </option>
       <option value="Dialog Semiconductor">
        Dialog Semiconductor
       </option>
      </select>


        </td>
        <td colspan="2"><input type="submit" name="submit" value="Search" style='margin-right:16px'/></td>

       <td colspan="3"><input type="submit" name="Search" value="Search All" style='margin-right:16px'/></td>

    
    </tr>



</form>



</table>

<table align="center" width="80%"   border="1" style="margin-top:20px;background-color:black;color:blanchedalmond ">
<tr style='background-color:blue;'>
<th class="text-center"> S NO:</th >
<th class="text-center">MID:</th>
<th class="text-center">Name:</th>
<th class="text-center">Project:</th>
<th class="text-center">Edit</th>
<th class="text-center">Delete</th>


</tr>
<?php

if(isset($_POST['submit'])){

    include ('dbconn.php');
    $MID=$_POST['MID'];
    $name=$_POST['name'];
    $project=$_POST['Projects'];

   if($MID != "" || $name != ""|| $project != ""){
    $sql="SELECT * FROM `add_employee` WHERE `MID`='$MID' OR `EMP_Name`='$name' OR  `projects_name`= '$project' ";
    $run=mysqli_query($conn,$sql);
    if(mysqli_num_rows($run)<1){
        echo"<tr><td colspan='5'>No records Founds</td></tr>";
    }
    else{$count=0;
        while($data=mysqli_fetch_assoc($run)){
                
                $count++;
                ?>
                <tr align="center" >
                <td><?php echo $count ?></td>
                <td><?php echo $data['MID']?></td>
                <td><?php echo $data['EMP_NAME']?></td>
                <td><?php echo $data['projects_name']?></td>
                <td><a href="update_form.php?sid=<?php echo $data['MID']; ?>">Edit</a></td>
                <td><button id="<?php echo $data['MID']; ?>" class="delbutton">Delete</button></td>


                </tr>
                
                
                
                <?php


        }
    }



   }
    

  



}


if(isset($_POST['Search'])){

    include ('dbconn.php');
    $MID=$_POST['MID'];
    $name=$_POST['name'];

    $sql="SELECT * FROM `add_employee` ";
    $run=mysqli_query($conn,$sql);
    if(mysqli_num_rows($run)<1){
        echo"<tr><td colspan='5'>No records Founds</td></tr>";
    }
    else{$count=0;
        while($data=mysqli_fetch_assoc($run)){
                
                $count++;
                ?>
                <tr align="center" >
                <td><?php echo $count ?></td>
                <td><?php echo $data['MID']?></td>
                <td><?php echo $data['EMP_NAME']?></td>
                <td><?php echo $data['projects_name']?></td>
                <td><a href="update_form.php?sid=<?php echo $data['MID']; ?>">Edit</a></td>
                <td><button id="<?php echo $data['MID']; ?>" class="delbutton" style="color: black">Delete</button></td>
               


                </tr>
                
                
                
                <?php


        }
    }







}


?>

</table>


<script type="text/javascript" >
        $(function() {

            $(".delbutton").click(function() {
                var del_id = $(this).attr("id");
                var info = 'id=' + del_id;
                if (confirm("Sure you want to delete this post? This cannot be undone later.")) {
                    $.ajax({
                        type : "POST",
                        url : "delete_employee.php", //URL to the delete php script
                        data : info,
                        success : function() {
                            location.reload();
                        }
                    });
                    $(this).parents(".record").animate("fast").animate({
                        opacity : "hide"
                    }, "slow");
                }
                return false;
            });
        });
 </script>


</body>
</html>




<?php
// include('dbconn.php');
// $query = "SELECT * FROM `add_employee` ";
// $run=mysqli_query($query);

 
 
// echo '<table border="0" cellspacing="2" cellpadding="2"> 
//       <tr> 
//           <td> <font face="Arial">Value1</font> </td> 
//           <td> <font face="Arial">Value2</font> </td> 
//           <td> <font face="Arial">Value3</font> </td> 
//           <td> <font face="Arial">Value4</font> </td> 
//           <td> <font face="Arial">Value5</font> </td> 
//       </tr>';
 
// if ($result = $mysqli->query($query)) {
    
//     while ($row = $result->fetch_assoc()) {
//         $field1name = $row["MID"];
//         $field2name = $row[""];
        
 
//         echo '<tr> 
//                   <td>'.$field1name.'</td> 
//                   <td>'.$field2name.'</td> 
//                   <td>'.$field3name.'</td> 
//                   <td>'.$field4name.'</td> 
//                   <td>'.$field5name.'</td> 
//               </tr>';
//     }
//     $result->free();
// } 
?>  
