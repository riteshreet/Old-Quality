<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>



<?php  

include("dbconn.php");  
$delete_id=$_GET['del'];  
$delete_query="DELETE  from `user_login` WHERE `MID`='$delete_id'";//delete query  
$run=mysqli_query($conn,$delete_query);  
if($run)  
{  
//javascript function to open in the same window   
    echo "<script>window.open('view.php?deleted=user has been deleted','_self')</script>";  
}  
  
?>  