<?php
session_start();

if(isset($_SESSION['uid'])){

    
}
else{
    header('location:admin_login.php');
}



?>

<?php
include ('header.php');
include ('titlehead.php');
?>

<html>  
<head lang="en">  
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> <!--css file link in bootstrap folder-->  
    <title>View Users</title>  
</head>  
<style>  
    .login-panel {  
        margin-top: 150px;  
    }  
    .table {  
        margin-top: 50px;  
  
    }  
  
</style>  
  
<body>  
  
<div class="container">  
   <u> <h1  align="center">All the Users</h1>  </u>
  

  
    <table class="table table-hover">
        <thead>  
  
        <tr>  

            <th>S No.</th>  
            <th>User MID</th>  
            <th>User Name</th>  
            <th>User E-mail</th>  
            <th>User Pass</th>  
            <th>Delete User</th>  
        </tr>  
        </thead>  
  
        <?php  
        include("dbconn.php");  
        $view_users_query="SELECT * FROM `user_login` ";//select query for viewing users.  
        $run=mysqli_query($conn,$view_users_query);//here run the sql query.  
  
        while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.  
        {  
            $s_no=$row['ID'];
            $user_id=$row['MID'];  
            
            $user_name=$row['NAME'];  
            $user_email=$row['EMAIL'];  
            $user_pass=$row['PASS'];  
  
  
  
        ?>  
        </tbody>
        <tr>  
<!--here showing results in the table -->  
            <td><?php echo $s_no;  ?></td>  
            <td><?php echo $user_id;  ?></td>  
            <td><?php echo $user_name;  ?></td>  
            <td><?php echo $user_email;  ?></td>  
            <td><?php echo $user_pass;  ?></td>  
            <td><a href="delete.php?del=<?php echo $user_id ?>"><button type="button" class="btn btn-danger">Delete</button></a></td> <!--btn btn-danger is a bootstrap button to show danger-->  
        </tr>  
  
        <?php } ?>  
        </tbody>
    </table>  
        </div>  

  
  
</body>  
  
</html>  