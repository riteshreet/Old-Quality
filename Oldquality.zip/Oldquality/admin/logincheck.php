<?php

session_start();


include 'dbconn.php';

if(isset($_POST['login'])){
    $username =$_POST['username'];
    $password =$_POST['password'];

    $sql= "SELECT * FROM `admin_login` WHERE `username`='$username' AND `password`='$password' ";

    $query= mysqli_query($conn,$sql);
    $row= mysqli_num_rows($query);

        if($row==1){
            echo "login successful";
            $data=mysqli_fetch_assoc($query);
            $id=$data['ID'];
            $_SESSION['uid']=$id;
            $_SESSION['user']=$username;
            header('location:admindash.php');

        }
        else{
           ?>
           <script>
               alert('Username and Password is incorrect !!!');
               window.open('admin_login.php','_self');
        </script>
           
           <?php
        }


    }

?>