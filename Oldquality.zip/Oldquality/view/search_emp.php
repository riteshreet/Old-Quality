<?php
session_start();

if(isset($_SESSION['email_user'])){

    
}
else{
    header('location:../user/Login.php');
}



?>


<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: Arial, Helvetica, sans-serif; color: black}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: white !important;} .asteriskField{color: red;}</style>




</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../index.php">Audit Portal</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="../user/Welcome.php">Home</a></li>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">

    <li> <a href="#"><?php echo $_SESSION['name_user'];?></a></li>
      <li><a href="Logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
     
    </ul>
  </div>
</nav>
<div class="bootstrap-iso">
 <div class="container">
  <div class="row">
   <div class="col-md-4 ">
    <form method="post">
     <div class="form-group ">
      <label class="control-label " for="ticket_no">
       Ticket No.
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-ticket">
        </i>
       </div>
       <input class="form-control" id="ticket_no" name="ticket_no" type="text"/>
       <div class="input-group-addon">
        <i class="fa ">
        </i>
       </div>
      </div>
      <span class="help-block" id="hint_ticket_no">
       Use to find Employee Record
      </span>
     </div>
</div>
<div class="col-md-4 ">
     <div class="form-group ">
      <label class="control-label " for="eng_name">
       Engineer Name
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-user">
        </i>
       </div>
       <input class="form-control" id="eng_name" name="eng_name" placeholder="Ex:- Rajib" type="text"/>
      </div>
      <span class="help-block" id="hint_eng_name">
       Letter Or Word
      </span>
     </div>
     </div>
     <div class="col-md-4 ">

     <div class="form-group">
      <div>
        <br>
        
       <button class="btn btn-primary " name="submit" type="submit">
        Search
       </button>
      </div>
     </div>
    </form>
   </div>
   </div>
   <div class="row">
   <u> <h1  align="center">Users</h1>  </u>
  

  
  <table class="table table-hover">
      <thead>  

      <tr>  

          <th>S No.</th>  
          <th>User MID</th>  
          <th>User Name</th>  
          <th>Ticket No.</th>        
          <th>Edit</th>  
          <th>Delete</th>  
      </tr>  
      </thead>  

      <?php 
      if(isset($_POST['submit'])){

        include ('dbconn.php');
        $ticket_no=$_POST['ticket_no'];
        $eng_name=$_POST['eng_name'];
        $auditor_mid=  $_SESSION['user_mid'];

      
    
       
        $sql="SELECT * FROM `bissell_call` WHERE `auditor_mid`='$auditor_mid' ";
        $run=mysqli_query($conn,$sql);
        
        if(mysqli_num_rows($run)<1){
            echo"<tr><td colspan='5'>No records Founds</td></tr>";
        }
        else{$count=0;
            while($data=mysqli_fetch_assoc($run)){
                    
                    $count++;
                    ?>
                    <tr align="center" >
                    <td><?php echo $count ?></td>
                    <td><?php echo $data['emp_id']?></td>
                    <td><?php echo $data['eng_name']?></td>
                    <td><?php echo $data['ticket_no']?></td>
                   
                    <td><a href="update_form.php?pid=<?php echo $data['PID']; ?>&amp;empid=<?php echo $data['emp_id']?>">Edit</a></td>
                    <td><button id="<?php echo $data['PID']; ?>" class="delbutton">Delete</button></td>
    
    
                    </tr>
                    
                    
                    
                    <?php
    
    
            }
        }
    
    
    
       
        
    
      
    
    
    
    }
     
     



      ?>  
      </tbody>
     
    
      </tbody>
  </table>  
      </div>  




   </div>
   </div>
   </div>

 


</body>
</html>