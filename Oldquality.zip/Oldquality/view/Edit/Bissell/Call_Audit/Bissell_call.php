<?php

$emp_id=$_GET['empid'];

echo $emp_id;

?>