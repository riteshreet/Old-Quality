<?php
session_start();

if(isset($_SESSION['email_user'])){

    
}



?>

<?php

include ('dbconn.php');
$pid=$_GET['pid'];
$emp_id=$_GET['empid'];

if($pid==10){//Bissell Call Audit
  header('location:Edit/Bissell/Call_Audit/Bissell_call.php?empid='.$emp_id);

}
else if($pid=20){ //Bissell process Audit
  header('location:Edit/Bissell/Process_audit/Bissell_process.php?empid='.$emp_id);
  
}




?>


</body>
</html>
