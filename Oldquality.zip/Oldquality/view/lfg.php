<?php
 include ('dbconn.php');
echo "LFG khul gya";
$sid=$_GET['sid'];
$qry= "SELECT * FROM `bissell_call` WHERE `ID`='$sid'";
$run=mysqli_query($conn,$qry);
$row=mysqli_fetch_array($run);

$a= $row['eng_name'];
echo $a;

?>