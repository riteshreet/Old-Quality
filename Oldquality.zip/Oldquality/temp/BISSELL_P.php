<?php
session_start();

if(isset($_SESSION['email_user'])){

    
}
else{
    header('location:../../user/Login.php');
}



?>
<!DOCTYPE html>
<html lang="en">
<?php
include("dbconn.php");
$sql = "SELECT `MID`, `EMP_NAME` FROM `add_employee`  ";
$result = $conn->query($sql);
$map;
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $map[$row['EMP_NAME']] = $row['MID'];
    }
}
?>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>BISSEL PROCESS AUDIT</title>    


  
<script type="text/javascript" src="jsfile.js"></script>
</head>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>


<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso12.css" /> 

<!--Font Awesome (added because you use icons in your prepend/append)-->
<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />

<!-- Inline CSS based on choices in "Settings" tab -->
<style>.bootstrap-iso .formden_header h2, .bootstrap-iso .formden_header p, .bootstrap-iso form{font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif; color: #000000}.bootstrap-iso form button, .bootstrap-iso form button:hover{color: #ffffff !important;} .asteriskField{color: red;}


</style>
<body onload="get_emp_id();procc_meth();">
<!-- HTML Form (wrapped in a .bootstrap-iso div) -->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="../../../index.php">Audit Portal</a>
    </div>
    <ul class="nav navbar-nav">
      <li class=""><a href="../../../user/Welcome.php">Home</a></li>
      
      <li><a href="../../../view/search_emp.php">View Data</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">

    <li> <a href="#"><?php echo $_SESSION['name_user'];?></a></li>
      <li><a href="../../../user/Logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
     
    </ul>
  </div>
</nav>



<div class="bootstrap-iso">
 <div class="container" style="background-color:rgba(187,221,189,0.549);"> 
  <form method="post" action="upload.php" name="audit_form">
   <div class="row" style="border-style:solid;border-width:2px;height:40px">
    <div class="col-md-12">
     <div class="form-group" align="center">
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold"> BISSEL PROCESS AUDIT </h4>
      </label>
     </div>	
	 </div>
	 </div>
	 <div class="row" style="border-style:solid;border-width:2px; height:40px"id="div_alert">
    <div class="col-md-12" >
     <div class="form-group" align="center" >
	 <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold" id="alert" style="background-color: green;">  BLUE ALERTS </h4>
      </label>
     </div>	
	 </div>
	 </div>   
	<div class="row" style="border-style:solid;border-width:2px">
	<div class="col-md-3 " >
     <div class="form-group"  >
	 
      <label class="control-label requiredField" for="eng_name" name="eng_name_label">
       Engineer Name :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="eng_name" name="eng_name" onchange="get_emp_id()" >
      <option disabled selected value> -- Select an option -- </option>
        <?php
            foreach($map as $name => $roll )
                echo "<option>".$name."</option>";
        ?>
      </select>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="ticket_no">
       Ticket Number :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="ticket_no" name="ticket_no" type="text"/>
     </div>
     <div class="form-group ">
      <label class="control-label requiredField" for="Resolver_Group">
      Resolver Group :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Resolver_Group" name="Resolver_Group" type="text"/>
     </div>
    </div>
    <!-- =====================================================Section 1============================================================== -->
  
   <div class="col-md-3 " >
    <div class="form-group ">
      <label class="control-label requiredField" for="emp_id">
       Employee ID :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="emp_id" name="emp_id" type="text"/>
     </div>
	 
     <div class="form-group ">
      <label class="control-label requiredField" for="date">
       Date :
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date" name="date" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
	 <div class="form-group ">
      <label class="control-label requiredField" for="date_log">
       Incident logged date:
       <span class="asteriskField">
        *
       </span>
      </label>
      <div class="input-group">
       <div class="input-group-addon">
        <i class="fa fa-calendar-plus-o">
        </i>
       </div>
       <input class="form-control" id="date_log" name="date_log" placeholder="MM/DD/YYYY" type="text"/>
      </div>
     </div>
    </div>
	
	<!-- =====================================================Section 2============================================================== -->
   <div class="col-md-3 " >
   <div class="form-group">
      <label class="control-label requiredField" for="Ticket_Status">
       Ticket Status:
       <span class="asteriskField">
        *
       </span>
      </label>
	  <select class="select form-control" id="Ticket_Status" name="Ticket_Status">
       <option disabled selected value> -- select an option -- </option>   
       <option value="In Progress">
        In Progress
       </option>
       <option value="On Hold">
       On Hold
       </option>
	    <option value="Resolved">
        Resolved
		</option>
		<option value="Closed">
        Closed
       </option>
	   <option value="Cancelled">
	   cancelled
      </select>
      
     </div>
    
	  
<div class="form-group ">
      <label class="control-label requiredField" for="inc_pri">
       Incident priority :
       <span class="asteriskField">
        *
       </span>
      </label>
      <select class="select form-control" id="inc_pri" name="inc_pri">
      <option disabled selected value> -- select an option -- </option>
       <option value="High">
        High
       </option>
       <option value="Medium">
        Medium
       </option>
	    <option value="Low">
        Low
      </select>
     </div>    

<div class="form-group ">
      <label class="control-label requiredField" for="Audited_by">
       Audited by :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="Audited_by" name="Audited_by" type="Audited_by" value="<?php echo $_SESSION['name_user'];?>" readonly/>
     </div>	 
    </div>

   <!-- =====================================================Section 3============================================================== -->
   <div class="col-md-3 " >
   <div class="form-group ">
      <label class="control-label requiredField" for="audit_score">
       Audit Score:
       <span class="asteriskField">
        *
       </span>
      </label>
	   <input class="form-control" id="overall_score" name="overall_score" type="text"readonly/>
     </div>    
   
      
	 
      <div class="form-group ">
      <label class="control-label requiredField" for="level">
       Level :
       <span class="asteriskField">
        *
       </span>
      </label>
      <input class="form-control" id="level_1" name="level_1" type="text"readonly >
     </div>
    </div>
   </div>
    <!-- =====================================================Section 4============================================================== -->
	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Process Methodology </h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>parameter</h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="eng_cont" name="eng_cont">
      Did the engineer contact the user within 1hr from ticket assignment? (Call):
      </label>
	 </div>

	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="tic_link" name="tic_link">
       Were the relavent tickets linked? (MI;Duplicate;Child):
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_case" name="cor_case"  style="color:red">
       Did the Engineer choose correct Case Type? (Incident/SR) :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_cat" name="cor_cat">
       Did the Engineer choose the correct  category,subcategory and item? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_pri" name="cor_pri">
       Did the Engineer choose the correct Priority? (Impact / Urgency, if priority is auto-populated) :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="cor_inc" name="cor_inc">
      Did the Engineer choose the correct incident state(New/In Progress/On Hold/Resolved/Cancelled/Transferred)?:
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="hold_reason" name="hold_reason">
       Did the Engineer choose the right 'On Hold Reason' when the ticket is kept on Hold? :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="rem_script" name="rem_script" style="color:red;">
       Was the remote script followed before taking a remote?:
      </label>
     </div>
	  <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="escalate" name="escalate">
       Did the Engineer Route/escalate the ticket to the correct resolver group, if required?:
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="Status" name="Status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="eng_cont" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="eng_cont" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="eng_cont" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="tic_link" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="tic_link" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="tic_link" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="cor_case" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="cor_case" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="cor_case" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="cor_cat" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="cor_cat" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="cor_cat" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="cor_pri" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="cor_pri" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="cor_pri" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	  
	 <input type="radio" id="exc" name="cor_inc" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="cor_inc" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="cor_inc" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br><br>
	 
	 <input type="radio" id="exc" name="hold_reason" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="hold_reason" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="hold_reason" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br>
	 
	 <input type="radio" id="exc" name="rem_script" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="rem_script" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="rem_script" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br>
	 
	  <input type="radio" id="exc" name="escalate" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="escalate" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="escalate" value="101" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br><br>

	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Audit score:
      </label>
	   <input type="text" id="overall_1" name="overall_1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="exampleTextarea"name="feedback1" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
<!-- #####################################section 3.0##################################################### -->

	<div class="row" style="border-style:solid;border-width:1.5px">
 	<div class="col-md-12 " >
     <div class="form-group" align="center">
	  <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Documentation</h4>
      </label>
     </div>	
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter</h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="pronunciation" name="pronunciation">
       Did the engineer update the short description appropriately?:
      </label>
	 </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity">
       Did the engineer mention the exact issue in the description tab ? :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity" style="color:red;">
       Did the engineer capture all the vital information? (Error screenshot if available,contact number):
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="flu" name="flu" style="color:red;">
       Did the engineer capture detailed documentation of troubleshooting steps?:
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity">
      Did the engineer use correct templates? (Email; Triage/Escalation):
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity">
       Was the ticket followed-up and documented  in a timely manner? :
      </label>
     </div>	 
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity">
     Did the engineer update relevant summary of the resolution under resolution notes? :
      </label>
     </div>
	  <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity">
       Did the engineer select the right resolution code while resolving the ticket? :
      </label>
     </div>
	 <div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="sp-Clarity" name="sp_clarity" style="color:red;">
      Did the engineer update the reference of Knowledge Base/SOP in the ticket?If there is no Knowledge Base/SOP available for that issue,a note regarding the same should be updated in the work notes.:
      </label>
     </div>
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="Status" name="Status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="pro" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="pro" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="pro" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="speech" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="speech" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="speech" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="rate" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="rate" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="rate" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="flu" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="flu" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="flu" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br>
	  
	 <input type="radio" id="exc" name="tone" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="tone" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="tone" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label> <br><br><br>
	  
	 <input type="radio" id="exc" name="gram" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="gram" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="gram" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br><br>
	 
	 <input type="radio" id="exc" name="gram" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="gram" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="gram" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br>
	 
	 <input type="radio" id="exc" name="gram" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="gram" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="gram" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br><br>
	 
	  <input type="radio" id="exc" name="gram" value="10" onclick="procc_meth()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="gram" value="0" onclick="procc_meth()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="gram" value="10" checked onclick="procc_meth()">
     <label for="male">NA</label><br><br><br><br><br>

	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Audit score:
      </label>
	   <input type="text" id="feedback" name="feedback1" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="exampleTextarea" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
  </div>
  </div>
 </div>
 
 
 
 
 <!-- =====================================================Section 4============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Resolution and Closure</h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="res_issue" name="res_issue">
       Was the technician able to resolve the issue? :
      </label>
	 </div>	 
	<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="res_provided" name="res_provided">
      Did the technician explain the resolution provided to the user? :
      </label>
     </div>	
<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="self_aut" name="self_aut" style="color:red">
      Did the technician help the user understand the usage of self-service portals and automation for generic application usage? :
      </label>
     </div>	
<div class="form-group" align="left" >	 
	  <label class="control-label requiredField" for="user_confim" name="user_confim" style="color:red">
      Did the technician get confirmation from the user before closing the issue? :
      </label>
     </div>		 
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4><br>
      </label>
     </div>
	 <input type="radio" id="exc" name="res_issue" value="10" onclick="courtesy_op()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="res_issue" value="0" onclick="courtesy_op()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="res_issue" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="exc" name="res_provided" value="10" onclick="courtesy_op()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="res_provided" value="0" onclick="courtesy_op()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="res_provided" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="self_aut" value="10" onclick="courtesy_op()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="self_aut" value="0" onclick="courtesy_op()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="self_aut" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br><br>
	 
	 <input type="radio" id="exc" name="user_confim" value="10" onclick="courtesy_op()">
     <label for="male">MET</label>
	 <input type="radio" id="good" name="user_confim" value="0" onclick="courtesy_op()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="user_confim" value="10" checked onclick="courtesy_op()">
     <label for="male">NA</label> <br><br>
	
	 </div>
	</div>
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="feedback" name="feedback2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="exampleTextarea" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
  
   <!-- =====================================================Section 0============================================================== -->
  <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-12 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4 style="font-weight:bold">Customer Expectation Management </h4>
      </label>
     </div>	
	 <div class="row" style="border-style:solid;border-width:1.5px">
 
	<div class="col-md-4 " >
     <div class="form-group" align="center">
	 
      <label class="control-label requiredField" for="parameter" name="parameter">
       <h4>Parameter </h4>
      </label>
     </div> 
	 <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="req_inform" name="req_inform">
      Was the User/Requestor kept informed about the progress of the ticket?
      </label>
	 </div>	 
	  <div class="form-group" align="left" >	 
      <label class="control-label requiredField" for="3_strike" name="3_strike">
      Did the engineer follow the 3 strike policy, if user was not responsive?
      </label>
	  
	 </div>	 	   	  
	</div>
	<div class="col-md-4 " >
     <div class="form-group" align="center" >
	 <div>
      <label class="control-label requiredField" for="status" name="status">
       <h4>Status </h4>
      </label>
     </div>
	 <br>
	 <input type="radio" id="yes" name="req_inform" value="10"  onclick="call_eqt()">
     <label for="male">MET</label>
	 <input type="radio" id="no" name="req_inform" value="0" onclick="call_eqt()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="req_inform" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br>
	 
	 <input type="radio" id="yes" name="3_strike" value="10" onclick="call_eqt()">
     <label for="male">MET</label>
	 <input type="radio" id="no" name="3_strike" value="0" onclick="call_eqt()">
     <label for="male">NOT MET</label> 
	 <input type="radio" id="na" name="3_strike" value="10" onclick="call_eqt()">
     <label for="male">NA</label> <br><br><br><br>
	 
	
	  
	 </div>
	</div>
	
	<div class="col-md-4 " >	
     <div class="form-group" align="center" >
	  <label class="control-label requiredField" for="ov-Perc" style="margin-top:20px;margin-left:-65px">
       Overall Percentage:
      </label>
	   <input type="text" id="feedback" name="feedback2" size="20" readonly><br><br>
	  <label class="control-label requiredField" for="level">
       Feedback
      </label>
     <textarea id="exampleTextarea" rows="3" style="margin: 0px; width: 355px; height: 98px;"></textarea>
     </div>
	</div>
   </div>
  </div>
  </div>
<br>
 
    <div class="col-md-12">
     <div class="form-group" align="center">
      <div>
       <button class="btn btn-info btn-sm" name="submit" type="submit">
        Submit
       </button>
       <!-- <button class="btn btn-info btn-sm"  onclick="myfunction()">
        send 
       </button> -->
      </div>
     </div>
	 </div>





</form>
      </div>
      </div>
     
	 




<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
	$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
	
	
	
		$(document).ready(function(){
		var date_input=$('input[name="date_log"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})
</script>



</body>

<html>