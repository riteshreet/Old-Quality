-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2020 at 08:14 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quality`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_employee`
--

CREATE TABLE `add_employee` (
  `MID` varchar(20) NOT NULL,
  `EMP_NAME` varchar(50) NOT NULL,
  `projects_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `add_employee`
--

INSERT INTO `add_employee` (`MID`, `EMP_NAME`, `projects_name`) VALUES
('M105568', 'ROhak', 'Lincoln Financial Group'),
('m123445', 'reet', 'Lincoln Financial Group'),
('M1052188', 'Naveen Kumar', 'Bissell'),
('M1066678', 'Rajib dey', 'GameStop');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `ID` tinyint(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`ID`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bissell_call`
--

CREATE TABLE `bissell_call` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `ticket_no` text NOT NULL,
  `vip_user` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `Audit_by` text NOT NULL,
  `call_no` text NOT NULL,
  `type_of_audit` text NOT NULL,
  `type_call` text NOT NULL,
  `overall_score` text NOT NULL,
  `level` text NOT NULL,
  `pro` text NOT NULL,
  `speech` text NOT NULL,
  `rate` text NOT NULL,
  `flu` text NOT NULL,
  `tone` text NOT NULL,
  `gram` text NOT NULL,
  `overall_1` text NOT NULL,
  `feedback_1` text NOT NULL,
  `court_Pro` text NOT NULL,
  `emp_own` text NOT NULL,
  `guide_ins` text NOT NULL,
  `overall_2` text NOT NULL,
  `feedback_2` text NOT NULL,
  `approp` text NOT NULL,
  `ho_mu` text NOT NULL,
  `call_pers` text NOT NULL,
  `automation_R` text NOT NULL,
  `ticket_no_call` text NOT NULL,
  `call_closed` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `listen_sk` text NOT NULL,
  `comp_sk` text NOT NULL,
  `pro_sk` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `use_pro` text NOT NULL,
  `reg_lan` text NOT NULL,
  `create_ticket` text NOT NULL,
  `eng_rude` text NOT NULL,
  `release_call` text NOT NULL,
  `overall_5` text NOT NULL,
  `feedback_5` text NOT NULL,
  `auditor_mid` text NOT NULL,
  `PID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bissell_call`
--

INSERT INTO `bissell_call` (`ID`, `eng_name`, `ticket_no`, `vip_user`, `emp_id`, `date`, `Audit_by`, `call_no`, `type_of_audit`, `type_call`, `overall_score`, `level`, `pro`, `speech`, `rate`, `flu`, `tone`, `gram`, `overall_1`, `feedback_1`, `court_Pro`, `emp_own`, `guide_ins`, `overall_2`, `feedback_2`, `approp`, `ho_mu`, `call_pers`, `automation_R`, `ticket_no_call`, `call_closed`, `overall_3`, `feedback_3`, `listen_sk`, `comp_sk`, `pro_sk`, `overall_4`, `feedback_4`, `use_pro`, `reg_lan`, `create_ticket`, `eng_rude`, `release_call`, `overall_5`, `feedback_5`, `auditor_mid`, `PID`) VALUES
(1, 'Naveen Kumar', '77678', 'Yes', 'M1052188', '03/19/2020', 'Rohan Kumar', '9108794569', 'live call', 'Inbound Call', '68.33', 'A', '10', '5', '5', '5', '5', '5', '58.33', '', '10', '5', '5', '66.67', '', '10', '10', '0', '101', '10', '10', '83.33', '', '0', '5', '5', '33.33', '', '10', '10', '10', '10', '10', '100', '', 'M1055567', 10),
(2, '', '', '', 'not found', '', 'Rohan Kumar', '', '', '', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '101', '101', '101', '100', '', 'M1055567', 10),
(3, 'ROhak', '77678', '', 'M105568', '03/18/2020', 'Rohan Kumar', '', '', '', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '101', '101', '101', '100', '', 'M1055567', 20),
(4, 'reet', '', '', 'm123445', '', 'Rohan Kumar', 'as', '', '', '0', '', '10', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '10', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '0', '101', '101', '0', '', 'M1055567', 20),
(5, 'reet', '', '', 'm123445', '', 'Rohan Kumar', 'afefaef', '', '', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '101', '101', '101', '100', '', 'M1055567', 0),
(6, 'reet', 'nm mn', '', 'm123445', '', 'Rohan Kumar', 'cvhj', '', '', '0', 'vcgf', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '0', '101', '101', '101', '101', '0', '', 'M1055567', 0),
(7, 'Naveen Kumar', '32432', 'Yes', 'M1052188', '03/12/2020', 'Rohan Kumar', '324324', 'live call', 'Outbound Call', '100.00', 'eefeF', '101', '101', '101', '101', '101', '101', '100.00', 'AWEF', '101', '101', '101', '100.00', 'FDF', '101', '101', '101', '101', '101', '101', '100.00', 'fee', '10', '10', '10', '100.00', 'FEF', '101', '101', '101', '101', '101', '100', 'ef', 'M1055567', 0),
(8, 'Suresh', '6789', 'yes', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'M10666789', 10),
(9, '', '', '', 'not found', '', 'Rohan Kumar', '', '', '', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '101', '101', '101', '100', '', 'M1055567', 10),
(10, 'ROhak', '', '', 'M105568', '', 'Rohan Kumar', '', '', '', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '101', '101', '101', '100.00', '', '101', '101', '101', '101', '101', '101', '100.00', '', '10', '10', '10', '100.00', '', '101', '101', '101', '101', '101', '100', '', 'M1055567', 10);

-- --------------------------------------------------------

--
-- Table structure for table `bissell_process`
--

CREATE TABLE `bissell_process` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `ticket_no` text NOT NULL,
  `Resolver_Group` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `date_log` text NOT NULL,
  `audit_score` text NOT NULL,
  `inc_pri` text NOT NULL,
  `Audited_by` text NOT NULL,
  `Ticket_Status` text NOT NULL,
  `level` text NOT NULL,
  `eng_cont` text NOT NULL,
  `tic_link` text NOT NULL,
  `cor_case` text NOT NULL,
  `cor_cat` text NOT NULL,
  `cor_pri` text NOT NULL,
  `cor_inc` text NOT NULL,
  `hold_reason` text NOT NULL,
  `rem_script` text NOT NULL,
  `escalate` text NOT NULL,
  `Audit_score0` text NOT NULL,
  `feedback_1` text NOT NULL,
  `appropriately` text NOT NULL,
  `exact_issue` text NOT NULL,
  `vital_information` text NOT NULL,
  `troubleshooting` text NOT NULL,
  `cor_temp` text NOT NULL,
  `followed_up` text NOT NULL,
  `summary` text NOT NULL,
  `right_resolve` text NOT NULL,
  `knowledge_base` text NOT NULL,
  `Audit_score1` text NOT NULL,
  `feedback_2` text NOT NULL,
  `res_issue` text NOT NULL,
  `res_provided` text NOT NULL,
  `self_aut` text NOT NULL,
  `user_confim` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `req_inform` text NOT NULL,
  `3_strike` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gamestop_call`
--

CREATE TABLE `gamestop_call` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `ticket_no` text NOT NULL,
  `vip_user` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `type_call` text NOT NULL,
  `call_no` text NOT NULL,
  `type_of_audit` text NOT NULL,
  `Audited_by` text NOT NULL,
  `overall_score` text NOT NULL,
  `level` text NOT NULL,
  `pronunciation` text NOT NULL,
  `sp_clarity` text NOT NULL,
  `rate_speech` text NOT NULL,
  `flu` text NOT NULL,
  `tone` text NOT NULL,
  `gram` text NOT NULL,
  `overall_1` text NOT NULL,
  `feedback_1` text NOT NULL,
  `court_Pro` text NOT NULL,
  `emp_own` text NOT NULL,
  `guide_ins` text NOT NULL,
  `overall_2` text NOT NULL,
  `feedback_2` text NOT NULL,
  `call_open` text NOT NULL,
  `contact_num` text NOT NULL,
  `ho_mu` text NOT NULL,
  `call_pers` text NOT NULL,
  `remote_R` text NOT NULL,
  `pas_res_R` text NOT NULL,
  `tran_script` text NOT NULL,
  `self_service` text NOT NULL,
  `issue_res` text NOT NULL,
  `ticket_num` text NOT NULL,
  `call_closed` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `listen` text NOT NULL,
  `para` text NOT NULL,
  `probing` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `use_pro_R` text NOT NULL,
  `reg_lan_R` text NOT NULL,
  `create_ticket_R` text NOT NULL,
  `eng_rude_R` text NOT NULL,
  `release_call_R` text NOT NULL,
  `overall_5` text NOT NULL,
  `feedback_5` text NOT NULL,
  `Auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gamestop_process`
--

CREATE TABLE `gamestop_process` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `ticket_no` text NOT NULL,
  `Incident_priority` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `inc_date` text NOT NULL,
  `Resolver_group` text NOT NULL,
  `Ticket_status` text NOT NULL,
  `Audited_by` text NOT NULL,
  `Audit_score` text NOT NULL,
  `level` text NOT NULL,
  `response_R` text NOT NULL,
  `rel_ticket` text NOT NULL,
  `cor_case` text NOT NULL,
  `ser_cat_R` text NOT NULL,
  `priority` text NOT NULL,
  `inc_state_R` text NOT NULL,
  `pending_reason_R` text NOT NULL,
  `remote_script_R` text NOT NULL,
  `escalate` text NOT NULL,
  `overall_1` text NOT NULL,
  `feedback_1` text NOT NULL,
  `des_appr` text NOT NULL,
  `issue` text NOT NULL,
  `call_source_R` text NOT NULL,
  `vital_inf` text NOT NULL,
  `troubleshooting` text NOT NULL,
  `cor_temp` text NOT NULL,
  `followed` text NOT NULL,
  `prop_process` text NOT NULL,
  `summary` text NOT NULL,
  `Knowledge_base` text NOT NULL,
  `overall_2` text NOT NULL,
  `feedback_2` text NOT NULL,
  `resolve` text NOT NULL,
  `explain_resolution` text NOT NULL,
  `selfservice_automation` text NOT NULL,
  `user_confirmation` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `progress` text NOT NULL,
  `3_strike_R` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `Auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lfg_call`
--

CREATE TABLE `lfg_call` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `ticket_no` text NOT NULL,
  `vip_user` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `type_of_call` text NOT NULL,
  `call_no` text NOT NULL,
  `type_of_audit` text NOT NULL,
  `overall_score` text NOT NULL,
  `level` text NOT NULL,
  `pronunciation` text NOT NULL,
  `sp_Clarity` text NOT NULL,
  `rate` text NOT NULL,
  `flu` text NOT NULL,
  `tone` text NOT NULL,
  `gram` text NOT NULL,
  `overall_1` text NOT NULL,
  `feedback_1` text NOT NULL,
  `courtesy` text NOT NULL,
  `empathy` text NOT NULL,
  `guide` text NOT NULL,
  `overall_2` text NOT NULL,
  `feedback_2` text NOT NULL,
  `greeting` text NOT NULL,
  `lan_id` text NOT NULL,
  `call_pers` text NOT NULL,
  `cont_no` text NOT NULL,
  `hold` text NOT NULL,
  `remote_ctrl` text NOT NULL,
  `tickets_no` text NOT NULL,
  `resol` text NOT NULL,
  `add_help` text NOT NULL,
  `call_closed` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `Listen_skill` text NOT NULL,
  `emp_own` text NOT NULL,
  `issue_1` text NOT NULL,
  `probing` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `use_pro` text NOT NULL,
  `reg_lang` text NOT NULL,
  `create_ticket` text NOT NULL,
  `eng_rude` text NOT NULL,
  `call_perm` text NOT NULL,
  `overall_5` text NOT NULL,
  `feedback_5` text NOT NULL,
  `auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `lfg_process`
--

CREATE TABLE `lfg_process` (
  `ID` int(11) NOT NULL,
  `eng_name` text NOT NULL,
  `inc_no` text NOT NULL,
  `inc_status` text NOT NULL,
  `emp_id` text NOT NULL,
  `date` text NOT NULL,
  `inc_priority` text NOT NULL,
  `Resolver_group` text NOT NULL,
  `inc_date` text NOT NULL,
  `Audit_by` text NOT NULL,
  `Audit_score` text NOT NULL,
  `level` text NOT NULL,
  `contact` text NOT NULL,
  `verification` text NOT NULL,
  `ticket_link` text NOT NULL,
  `ci_symp` text NOT NULL,
  `priority` text NOT NULL,
  `cor_inc` text NOT NULL,
  `script` text NOT NULL,
  `escalate` text NOT NULL,
  `overall_1` text NOT NULL,
  `feedback_1` text NOT NULL,
  `description` text NOT NULL,
  `vital_information` text NOT NULL,
  `troubleshooting` text NOT NULL,
  `template` text NOT NULL,
  `followed_up` text NOT NULL,
  `summary` text NOT NULL,
  `resolution` text NOT NULL,
  `knowledge_base` text NOT NULL,
  `overall_2` text NOT NULL,
  `feedback_2` text NOT NULL,
  `resolve_issue` text NOT NULL,
  `resolution_provided` text NOT NULL,
  `confirm_tic` text NOT NULL,
  `overall_3` text NOT NULL,
  `feedback_3` text NOT NULL,
  `ticket_progress` text NOT NULL,
  `3_strike` text NOT NULL,
  `overall_4` text NOT NULL,
  `feedback_4` text NOT NULL,
  `auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test1`
--

CREATE TABLE `test1` (
  `ID` int(11) NOT NULL,
  `emp_id` text NOT NULL,
  `vip_user` text NOT NULL,
  `auditor_mid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `test1`
--

INSERT INTO `test1` (`ID`, `emp_id`, `vip_user`, `auditor_mid`) VALUES
(1, 'M1066678', 'No', 'M1055567');

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

CREATE TABLE `user_login` (
  `ID` int(11) NOT NULL,
  `MID` text NOT NULL,
  `NAME` text NOT NULL,
  `EMAIL` text NOT NULL,
  `PASS` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`ID`, `MID`, `NAME`, `EMAIL`, `PASS`) VALUES
(22, 'M1055567', 'Rohan Kumar', 'rohan.kumar2@mindtree.com', '123456789'),
(23, 'M1054381', 'Suyash ', 'suyash@mindtree.com', '1234567');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bissell_call`
--
ALTER TABLE `bissell_call`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bissell_process`
--
ALTER TABLE `bissell_process`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gamestop_call`
--
ALTER TABLE `gamestop_call`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `gamestop_process`
--
ALTER TABLE `gamestop_process`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lfg_call`
--
ALTER TABLE `lfg_call`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `lfg_process`
--
ALTER TABLE `lfg_process`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `test1`
--
ALTER TABLE `test1`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user_login`
--
ALTER TABLE `user_login`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `ID` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bissell_call`
--
ALTER TABLE `bissell_call`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `bissell_process`
--
ALTER TABLE `bissell_process`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamestop_call`
--
ALTER TABLE `gamestop_call`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gamestop_process`
--
ALTER TABLE `gamestop_process`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lfg_call`
--
ALTER TABLE `lfg_call`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lfg_process`
--
ALTER TABLE `lfg_process`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `test1`
--
ALTER TABLE `test1`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_login`
--
ALTER TABLE `user_login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
